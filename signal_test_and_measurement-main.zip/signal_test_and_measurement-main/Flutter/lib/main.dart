import 'package:flutter/material.dart';

// Screens
import 'package:signal_test_and_measurement/screens/live_screen.dart';
import 'package:signal_test_and_measurement/screens/logs_screen.dart';
import 'package:signal_test_and_measurement/screens/map_screen.dart';
import 'package:signal_test_and_measurement/services/bg_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Starts the native foreground logger (no-op without permissions).
  // Remove this line if you do NOT want background recording.
  try { await BtsBgService.ensureStarted(); } catch (_) {}

  runApp(const SignalApp());
}

class SignalApp extends StatelessWidget {
  const SignalApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Signal Test & Measurement',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const _RootShell(),
    );
  }
}

class _RootShell extends StatefulWidget {
  const _RootShell({super.key});
  @override
  State<_RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<_RootShell> {
  int _index = 0;

  // NOT const – these widgets are not compile-time constants.
  final List<Widget> _pages = <Widget>[
    LiveScreen(),  // Live
    LogsScreen(),  // Logs
    MapScreen(),   // Map
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        type: BottomNavigationBarType.fixed,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.insights), label: 'Live'),
          BottomNavigationBarItem(icon: Icon(Icons.list),     label: 'Logs'),
          BottomNavigationBarItem(icon: Icon(Icons.map),      label: 'Map'),
        ],
      ),
    );
  }
}
