import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../services/log_db.dart';

class LogsScreen extends StatefulWidget {
  const LogsScreen({super.key});

  @override
  State<LogsScreen> createState() => _LogsScreenState();
}

class _LogsScreenState extends State<LogsScreen> {
  bool _busy = false;
  List<LogSession> _sessions = [];

  @override
  void initState() {
    super.initState();
    _initAndLoad();
  }

  Future<void> _initAndLoad() async {
    setState(() => _busy = true);
    try {
      await LogDb.instance.init();
      await _load();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _load() async {
    final items = await LogDb.instance.listSessions();
    if (mounted) setState(() => _sessions = items);
  }

  Future<void> _onRefresh() async {
    await _load();
  }

  // --- Formatting helpers ---
  String _fmtDateTime(int millis) {
    final dt = DateTime.fromMillisecondsSinceEpoch(millis).toLocal();
    String two(int n) => n.toString().padLeft(2, '0');
    return '${dt.year}-${two(dt.month)}-${two(dt.day)} ${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
  }

  String _fmtDuration(int startMs, int? endMs) {
    final end = endMs ?? DateTime.now().millisecondsSinceEpoch;
    final d = Duration(milliseconds: (end - startMs).clamp(0, 1 << 62));
    String two(int n) => n.toString().padLeft(2, '0');
    final h = d.inHours;
    final m = d.inMinutes.remainder(60);
    final s = d.inSeconds.remainder(60);
    return h > 0 ? '${two(h)}:${two(m)}:${two(s)}' : '${two(m)}:${two(s)}';
  }

  String _fmtRat(LogSession s) {
    if (s.rat == 'NR') {
      final mode = (s.nrMode ?? '').toUpperCase();
      if (mode == 'SA') return '5G SA';
      if (mode == 'NSA') return '5G NSA';
      return '5G';
    }
    return '4G LTE';
  }

  // --- Actions ---
  Future<void> _export(LogSession s) async {
    setState(() => _busy = true);
    try {
      final path = await LogDb.instance.exportSessionCsv(s.id);
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Exported CSV: $path')),
      );

      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Export complete'),
          content: SelectableText(path),
          actions: [
            TextButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: path));
                Navigator.of(ctx).pop();
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Path copied to clipboard')),
                );
              },
              child: const Text('Copy path'),
            ),
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Export failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _delete(LogSession s) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete session?'),
        content: Text('This will permanently remove session #${s.id} and ${s.sampleCount} samples.'),
        actions: [
          TextButton(onPressed: () => Navigator.of(ctx).pop(false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.of(ctx).pop(true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;

    setState(() => _busy = true);
    try {
      await LogDb.instance.deleteSession(s.id);
      await _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Deleted')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Delete failed: $e')),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final body = _sessions.isEmpty
        ? const _EmptyLogsPlaceholder()
        : RefreshIndicator(
      onRefresh: _onRefresh,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
        itemCount: _sessions.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (ctx, i) {
          final s = _sessions[i];
          final rat = _fmtRat(s);
          final start = _fmtDateTime(s.startTs);
          final dur = _fmtDuration(s.startTs, s.endTs);

          // Display index: 0-based, re-numbered after deletions (latest first).
          final displayIndex = _sessions.length - 1 - i;

          final cc = <String>[];
          if (s.mcc != null && s.mnc != null) cc.add('MCC ${s.mcc} / MNC ${s.mnc}');
          if (s.cid != null) cc.add('CID ${s.cid}');
          if (s.pci != null) cc.add('PCI ${s.pci}');
          final meta = cc.join('  ·  ');

          return Card(
            child: ListTile(
              leading: Icon(
                s.rat == 'NR' ? Icons.five_g : Icons.network_cell,
                color: s.rat == 'NR' ? Colors.blue : Colors.green,
              ),
              title: Text('Session #$displayIndex • $rat'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$start   •   Duration $dur'),
                  Text('Samples: ${s.sampleCount}${meta.isNotEmpty ? '   •   $meta' : ''}'),
                ],
              ),
              isThreeLine: true,
              trailing: Wrap(
                spacing: 8,
                children: [
                  IconButton(
                    tooltip: 'Export CSV',
                    icon: const Icon(Icons.upload_file),
                    onPressed: _busy ? null : () => _export(s),
                  ),
                  IconButton(
                    tooltip: 'Delete',
                    icon: const Icon(Icons.delete_outline),
                    onPressed: _busy ? null : () => _delete(s),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Logs'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh),
            onPressed: _busy ? null : _onRefresh,
          ),
        ],
      ),
      body: Stack(
        children: [
          body,
          if (_busy)
            const PositionedFill(
              child: IgnorePointer(
                child: ColoredBox(
                  color: Color(0x11000000),
                  child: Center(child: CircularProgressIndicator()),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class PositionedFill extends StatelessWidget {
  const PositionedFill({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Positioned(top: 0, right: 0, bottom: 0, left: 0, child: child);
  }
}

class _EmptyLogsPlaceholder extends StatelessWidget {
  const _EmptyLogsPlaceholder();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.receipt_long, size: 48, color: Colors.black38),
            SizedBox(height: 12),
            Text(
              'No sessions yet',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 4),
            Text(
              'Start and stop recording on the Live tab to capture KPIs.\n'
                  'Exports are saved as CSV files.',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }
}
