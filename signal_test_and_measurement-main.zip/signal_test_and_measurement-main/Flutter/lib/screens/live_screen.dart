
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/log_db.dart';
import 'speed_screen.dart';

class LiveScreen extends StatefulWidget {
  const LiveScreen({super.key});

  @override
  State<LiveScreen> createState() => _LiveScreenState();
}

class _LiveScreenState extends State<LiveScreen> with WidgetsBindingObserver {
  // -------- Stream / model --------
  static const _btsChannel = EventChannel('bts/info');
  LiveSnapshot? _last;
  StreamSubscription<dynamic>? _sub;

  // -------- Chart buffers --------
  final int _maxPoints = 180; // ~3 minutes @ 1 Hz
  final List<FlSpot> _rsrpSeries = [];
  final List<FlSpot> _rsrqSeries = [];
  final List<FlSpot> _sinrSeries = [];
  double _t = 0; // time index (seconds), increments per snapshot

  // -------- Thresholds (defaults + persisted) --------
  static const double _defaultRsrp = -110; // dBm
  static const double _defaultRsrq = -14;  // dB
  static const double _defaultSinr = 5;    // dB

  double _thRsrp = _defaultRsrp;
  double _thRsrq = _defaultRsrq;
  double _thSinr = _defaultSinr;

  // -------- Permissions / lifecycle --------
  bool _permissionsMissing = false;
  bool _isForeground = true;

  // -------- Recording state --------
  bool _recording = false;
  int? _sessionId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadPrefs();
    _initDb();
    _startStream();
  }

  Future<void> _initDb() async {
    // Initialize logs DB once; UI still works if this fails.
    try {
      await LogDb.instance.init();
    } catch (_) {
      // Ignore init errors.
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _sub?.cancel();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    _isForeground = state == AppLifecycleState.resumed;
  }

  // -------- Persistence --------
  Future<void> _loadPrefs() async {
    final sp = await SharedPreferences.getInstance();
    setState(() {
      _thRsrp = sp.getDouble('th_rsrp') ?? _defaultRsrp;
      _thRsrq = sp.getDouble('th_rsrq') ?? _defaultRsrq;
      _thSinr = sp.getDouble('th_sinr') ?? _defaultSinr;
    });
  }

  Future<void> _saveTh(String key, double v) async {
    final sp = await SharedPreferences.getInstance();
    await sp.setDouble(key, v);
  }

  // -------- Stream handling --------
  void _startStream() {
    _sub?.cancel();
    _sub = _btsChannel.receiveBroadcastStream().listen(
          (raw) {
        try {
          final obj = jsonDecode(raw as String) as Map<String, dynamic>;

          // Permission hint from native side
          if (obj['error'] == 'permission_missing') {
            if (!_permissionsMissing) setState(() => _permissionsMissing = true);
            return;
          } else if (_permissionsMissing) {
            setState(() => _permissionsMissing = false);
          }

          final snap = LiveSnapshot.fromJson(obj);
          _last = snap;

          // Advance shared time index once per snapshot
          final tNext = _t + 1.0;

          void push(List<FlSpot> buf, double? v) {
            if (v == null) return;
            buf.add(FlSpot(tNext, v));
            if (buf.length > _maxPoints) buf.removeAt(0);
          }

          push(_rsrpSeries, snap.rsrp);
          push(_rsrqSeries, snap.rsrq);
          push(_sinrSeries, snap.sinr);
          _t = tNext;

          // If recording, write the sample to DB (fire-and-forget)
          if (_recording && _sessionId != null) {
            final lite = SnapshotLite(
              rat: snap.rat,
              nrMode: snap.nrMode,
              mcc: snap.mcc,
              mnc: snap.mnc,
              tac: snap.tac,
              lac: snap.lac,
              cid: snap.cid,
              pci: snap.pci,
              earfcn: snap.earfcn,
              nrarfcn: snap.nrarfcn,
              nci: snap.nci,
              rsrp: snap.rsrp,
              rsrq: snap.rsrq,
              sinr: snap.sinr,
              timestamp: snap.timestamp ?? DateTime.now().millisecondsSinceEpoch,
            );
            unawaited(LogDb.instance.insertSample(_sessionId!, lite));
          }

          if (mounted) setState(() {});
        } catch (_) {
          // Ignore malformed frames.
        }
      },
      onError: (_) {},
      cancelOnError: false,
    );
  }

  Future<void> _requestPermissions() async {
    final results = await [Permission.phone, Permission.location].request();
    final okPhone = results[Permission.phone]?.isGranted ?? false;
    final okLoc = results[Permission.location]?.isGranted ?? false;
    setState(() => _permissionsMissing = !(okPhone && okLoc));
  }

  // -------- Recording actions --------
  Future<void> _toggleRecording() async {
    if (_recording) {
      // Stop
      final sid = _sessionId;
      setState(() {
        _recording = false;
        _sessionId = null;
      });
      if (sid != null) {
        try {
          await LogDb.instance.endSession(sid);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Recording stopped')),
          );
        } catch (_) {
          // Ignore
        }
      }
    } else {
      // Start
      try {
        final lite = _last == null
            ? null
            : SnapshotLite(
          rat: _last!.rat,
          nrMode: _last!.nrMode,
          mcc: _last!.mcc,
          mnc: _last!.mnc,
          tac: _last!.tac,
          lac: _last!.lac,
          cid: _last!.cid,
          pci: _last!.pci,
          earfcn: _last!.earfcn,
          nrarfcn: _last!.nrarfcn,
          nci: _last!.nci,
          rsrp: _last!.rsrp,
          rsrq: _last!.rsrq,
          sinr: _last!.sinr,
          timestamp: _last!.timestamp,
        );
        final sid = await LogDb.instance.startSession(lite);
        setState(() {
          _recording = true;
          _sessionId = sid;
        });
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Recording started (session #$sid)')),
        );
      } catch (e) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not start recording: $e')),
        );
      }
    }
  }

  // -------- UI --------
  @override
  Widget build(BuildContext context) {
    final snap = _last;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Text('Live KPIs'),
            if (_recording) ...[
              const SizedBox(width: 8),
              // Red dot indicates active recording
              const Icon(Icons.fiber_manual_record, size: 16, color: Colors.red),
            ],
          ],
        ),
        actions: [
          IconButton(
            tooltip: _recording ? 'Stop recording' : 'Start recording',
            icon: Icon(
              _recording ? Icons.stop_circle_outlined : Icons.fiber_manual_record,
              color: _recording ? Colors.red : null,
            ),
            onPressed: _toggleRecording,
          ),
          IconButton(
            tooltip: 'Open Speed test',
            icon: const Icon(Icons.speed),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const SpeedScreen()),
              );
            },
          ),
        ],
      ),
      body: _permissionsMissing
          ? _buildPermissionsCard()
          : ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (snap != null) _buildTopInfoCard(snap) else _buildWaitingCard(),
          const SizedBox(height: 12),
          _buildSettingsCard(), // thresholds (RSRP/RSRQ/SINR)
          const SizedBox(height: 12),
          _buildChartsSection(), // three charts
          const SizedBox(height: 12),
          _buildKpisCard(snap), // numeric KPIs
        ],
      ),
    );
  }

  Widget _buildPermissionsCard() {
    return Center(
      child: Card(
        margin: const EdgeInsets.all(24),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Permissions required', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 8),
            const Text('Phone + Location permissions are needed to read serving cell KPIs.',
                textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton.icon(
              icon: const Icon(Icons.lock_open),
              label: const Text('Grant permissions'),
              onPressed: _requestPermissions,
            ),
          ]),
        ),
      ),
    );
  }

  Widget _buildTopInfoCard(LiveSnapshot s) {
    final ratLabel = () {
      if (s.rat == 'NR') {
        final mode = (s.nrMode ?? '').toUpperCase();
        if (mode == 'SA') return '5G SA';
        if (mode == 'NSA') return '5G NSA';
        return '5G';
      }
      return '4G LTE';
    }();

    final idLine = [
      if (s.mcc != null && s.mnc != null) 'MCC ${s.mcc} / MNC ${s.mnc}',
      if (s.tac != null) 'TAC ${s.tac}',
      if (s.cid != null) 'CID ${s.cid}',
      if (s.nci != null) 'NCI ${s.nci}',
      if (s.pci != null) 'PCI ${s.pci}',
    ].join('  ·  ');

    return Card(
      child: ListTile(
        leading: Icon(
          s.rat == 'NR' ? Icons.five_g : Icons.network_cell,
          color: s.rat == 'NR' ? Colors.blue : Colors.green,
        ),
        title: Text(ratLabel),
        subtitle: Text(idLine.isEmpty ? 'Reading cell identity…' : idLine),
        trailing: Text(
          _fmtTime(s.timestamp),
          style: const TextStyle(fontSize: 12, color: Colors.black54),
        ),
      ),
    );
  }

  Widget _buildWaitingCard() {
    return const Card(
      child: ListTile(
        leading: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)),
        title: Text('Waiting for modem data…'),
        subtitle: Text('Make sure permissions are granted and the screen stays on.'),
      ),
    );
  }

  // ---- Settings (thresholds) ----
  Widget _buildSettingsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Thresholds', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Wrap(
            runSpacing: 8,
            spacing: 16,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              _thresholdField(
                label: 'RSRP (dBm)',
                value: _thRsrp,
                onSubmit: (v) async {
                  final nv = double.tryParse(v);
                  if (nv != null) {
                    await _saveTh('th_rsrp', nv);
                    setState(() => _thRsrp = nv);
                  }
                },
              ),
              _thresholdField(
                label: 'RSRQ (dB)',
                value: _thRsrq,
                onSubmit: (v) async {
                  final nv = double.tryParse(v);
                  if (nv != null) {
                    await _saveTh('th_rsrq', nv);
                    setState(() => _thRsrq = nv);
                  }
                },
              ),
              _thresholdField(
                label: 'SINR (dB)',
                value: _thSinr,
                onSubmit: (v) async {
                  final nv = double.tryParse(v);
                  if (nv != null) {
                    await _saveTh('th_sinr', nv);
                    setState(() => _thSinr = nv);
                  }
                },
              ),
            ],
          ),
          const SizedBox(height: 6),
          const Text(
            'Tip: The dashed line in each chart marks its threshold.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ]),
      ),
    );
  }

  Widget _thresholdField({
    required String label,
    required double value,
    required Future<void> Function(String) onSubmit,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label),
        const SizedBox(width: 8),
        SizedBox(
          width: 90,
          child: TextFormField(
            initialValue: value.toStringAsFixed(0),
            keyboardType: const TextInputType.numberWithOptions(signed: true, decimal: true),
            decoration: const InputDecoration(isDense: true, border: OutlineInputBorder()),
            onFieldSubmitted: onSubmit,
          ),
        ),
      ],
    );
  }

  // ---- Charts (3x) ----
  Widget _buildChartsSection() {
    return Column(
      children: [
        _chartCard(
          title: 'RSRP (dBm)',
          series: _rsrpSeries,
          yMin: -140,
          yMax: -50,
          threshold: _thRsrp,
          color: Colors.blue,
        ),
        const SizedBox(height: 12),
        _chartCard(
          title: 'RSRQ (dB)',
          series: _rsrqSeries,
          yMin: -20,
          yMax: 0,
          threshold: _thRsrq,
          color: Colors.deepPurple,
        ),
        const SizedBox(height: 12),
        _chartCard(
          title: 'SINR (dB)',
          series: _sinrSeries,
          yMin: -5,
          yMax: 30,
          threshold: _thSinr,
          color: Colors.teal,
        ),
      ],
    );
  }

  Widget _chartCard({
    required String title,
    required List<FlSpot> series,
    required double yMin,
    required double yMax,
    required double threshold,
    required Color color,
  }) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: SizedBox(
        height: 220,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(8, 12, 16, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 6),
                child: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
              ),
              Expanded(
                child: LineChart(
                  LineChartData(
                    minY: yMin,
                    maxY: yMax,
                    gridData: const FlGridData(show: true),
                    titlesData: FlTitlesData(
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(showTitles: true, reservedSize: 36),
                      ),
                      bottomTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      rightTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                      topTitles: const AxisTitles(
                        sideTitles: SideTitles(showTitles: false),
                      ),
                    ),
                    borderData: FlBorderData(show: true),
                    lineBarsData: [
                      LineChartBarData(
                        spots: List<FlSpot>.from(series),
                        isCurved: true,
                        barWidth: 2,
                        color: color,
                        dotData: const FlDotData(show: false),
                      ),
                    ],
                    extraLinesData: ExtraLinesData(horizontalLines: [
                      HorizontalLine(
                        y: threshold,
                        dashArray: [8, 6],
                        strokeWidth: 2,
                        color: Colors.red.withOpacity(0.85),
                      ),
                    ]),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ---- Numeric KPIs ----
  Widget _buildKpisCard(LiveSnapshot? s) {
    String vOrDash(num? v, {String unit = ''}) {
      if (v == null) return '-';
      final txt = v is double ? v.toStringAsFixed(1) : v.toString();
      return unit.isEmpty ? txt : '$txt $unit';
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('KPIs', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _kv('RSRP', vOrDash(s?.rsrp, unit: 'dBm')),
          _kv('RSRQ', vOrDash(s?.rsrq, unit: 'dB')),
          _kv('SINR', vOrDash(s?.sinr, unit: 'dB')),
          const Divider(),
          _kv('EARFCN', s?.earfcn?.toString() ?? '-'),
          _kv('NRARFCN', s?.nrarfcn?.toString() ?? '-'),
          _kv('PCI', s?.pci?.toString() ?? '-'),
        ]),
      ),
    );
  }

  Widget _kv(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 120, child: Text(k)),
          Expanded(child: Text(v, textAlign: TextAlign.right)),
        ],
      ),
    );
  }

  String _fmtTime(int? tsMs) {
    if (tsMs == null) return '';
    final dt = DateTime.fromMillisecondsSinceEpoch(tsMs).toLocal();
    String two(int x) => x.toString().padLeft(2, '0');
    return '${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
  }
}

// -------- Data model --------

class LiveSnapshot {
  final String rat; // "LTE" or "NR"
  final String? nrMode; // "SA" or "NSA"
  final int? mcc, mnc, tac, lac, cid, pci, earfcn, nrarfcn;
  final int? nci;
  final double? rsrp, rsrq, sinr;
  final int? timestamp;

  LiveSnapshot({
    required this.rat,
    this.nrMode,
    this.mcc,
    this.mnc,
    this.tac,
    this.lac,
    this.cid,
    this.nci,
    this.pci,
    this.earfcn,
    this.nrarfcn,
    this.rsrp,
    this.rsrq,
    this.sinr,
    this.timestamp,
  });

  factory LiveSnapshot.fromJson(Map<String, dynamic> j) {
    double? d(dynamic x) {
      if (x == null) return null;
      if (x is num) return x.toDouble();
      return double.tryParse(x.toString());
    }

    int? i(dynamic x) {
      if (x == null) return null;
      if (x is num) return x.toInt();
      return int.tryParse(x.toString());
    }

    return LiveSnapshot(
      rat: (j['rat'] as String?) ?? 'LTE',
      nrMode: j['nrMode'] as String?,
      mcc: i(j['mcc']),
      mnc: i(j['mnc']),
      tac: i(j['tac']),
      lac: i(j['lac']),
      cid: i(j['cid']),
      nci: (j['nci'] == null)
          ? null
          : (j['nci'] is int ? j['nci'] as int : int.tryParse(j['nci'].toString())),
      pci: i(j['pci']),
      earfcn: i(j['earfcn']),
      nrarfcn: i(j['nrarfcn']),
      rsrp: d(j['rsrp']),
      rsrq: d(j['rsrq']),
      sinr: d(j['sinr']),
      timestamp: i(j['timestamp']),
    );
  }
}
