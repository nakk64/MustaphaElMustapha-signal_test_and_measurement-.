import 'dart:async';
import 'dart:io';
import 'dart:math';

import 'package:flutter/material.dart';

class SpeedScreen extends StatefulWidget {
  const SpeedScreen({super.key});

  @override
  State<SpeedScreen> createState() => _SpeedScreenState();
}

class _SpeedScreenState extends State<SpeedScreen> {
  // ---------------- Tunables ----------------
  // Global watchdog to avoid hanging runs.
  static const Duration _globalWatchdog = Duration(seconds: 60);

  // Per-request/connectivity timeouts.
  static const Duration _perRequestTimeout = Duration(seconds: 8);
  static const Duration _preflightTimeout = Duration(seconds: 4);

  // Stream stall (no data for this long → restart worker).
  static const Duration _stallTimeout = Duration(seconds: 4);

  // Ping phase
  static const int pingSamples = 15;
  static const Duration pingInterval = Duration(milliseconds: 250);

  // Download phase
  static const int dlParallel = 6;
  static const Duration dlDuration = Duration(seconds: 12);
  static const Duration dlWarmup = Duration(seconds: 1);
  static const int dlMaxBytes = 20 * 1024 * 1024; // 20 MB cap

  // Upload phase
  static const int ulParallel = 3;
  static const Duration ulDuration = Duration(seconds: 10);
  static const Duration ulWarmup = Duration(seconds: 1);
  static const int ulMaxBytes = 5 * 1024 * 1024; // 5 MB cap
  static const int ulChunkSize = 64 * 1024; // 64 KB

  // Connectivity & server candidates
  static const _connectivityUrls = <String>[
    'https://www.google.com/generate_204',
    'https://httpstat.us/204',
    'https://clients3.google.com/generate_204',
  ];

  static const _downloadCandidates = <String>[
    // Large files from different CDNs in EU/DE vicinity.
    'https://speed.hetzner.de/100MB.bin',
    'https://download-test.cloudflare.com/100mb.bin',
    'https://proof.ovh.net/files/100Mb.dat',
    'https://speedtest.tele2.net/100MB.zip',
    'https://ipv4.download.thinkbroadband.com/100MB.zip',
  ];

  static const _uploadCandidates = <String>[
    'https://httpbin.org/post',
    'https://postman-echo.com/post',
  ];

  // ---------------- State ----------------
  bool _running = false;
  bool _cancelled = false;

  Timer? _watchdog;

  String _phase = 'Idle';
  String _server = 'Auto';
  String _downloadUrl = 'Auto';
  String _uploadUrl = 'Auto';
  String? _statusNote; // shows errors like "No download server reachable"

  DateTime? _startedAt;

  // Ping
  double _pingMedian = 0.0;
  double _pingP95 = 0.0;
  double _pingJitter = 0.0;

  // Download
  double _dlMbps = 0.0;
  int _dlBytes = 0;

  // Upload
  double _ulMbps = 0.0;
  int _ulBytes = 0;

  @override
  void dispose() {
    _watchdog?.cancel();
    _cancelled = true;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final canStart = !_running;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Speed'),
        actions: [
          if (_running)
            TextButton.icon(
              style: TextButton.styleFrom(foregroundColor: Colors.black),
              onPressed: _cancelTest,
              icon: const Icon(Icons.stop, size: 18),
              label: const Text('Cancel'),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildHeaderCard(),
          const SizedBox(height: 12),
          FilledButton.icon(
            icon: const Icon(Icons.speed),
            onPressed: canStart ? _runTest : null,
            label: Text(canStart ? 'Start test' : 'Running…'),
          ),
          const SizedBox(height: 12),
          _buildLiveCard(),
          const SizedBox(height: 12),
          _buildResultsCard(),
          const SizedBox(height: 4),
          const Text(
            'Note: HTTP latency approximates real app experience. Throughput depends on server proximity and carrier policies.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }

  Card _buildHeaderCard() {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.cloud_outlined),
        title: Text('Phase: $_phase'),
        subtitle: Text(_statusNote == null ? 'Server: ${_server == "Auto" ? "Auto-select" : _server}' : _statusNote!),
        trailing: _running
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2))
            : IconButton(
          tooltip: 'Reset',
          icon: const Icon(Icons.refresh),
          onPressed: _running ? null : _resetAll,
        ),
      ),
    );
  }

  Widget _buildLiveCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Live', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _kv('Ping (median)', _pingMedian > 0 ? '${_pingMedian.toStringAsFixed(1)} ms' : '-'),
            _kv('Ping p95', _pingP95 > 0 ? '${_pingP95.toStringAsFixed(1)} ms' : '-'),
            _kv('Ping jitter', _pingJitter > 0 ? '${_pingJitter.toStringAsFixed(1)} ms' : '-'),
            const Divider(),
            _kv('Download', _dlMbps > 0 ? '${_dlMbps.toStringAsFixed(1)} Mbps' : '-'),
            _kv('Downloaded', _dlBytes > 0 ? _fmtBytes(_dlBytes) : '-'),
            const Divider(),
            _kv('Upload', _ulMbps > 0 ? '${_ulMbps.toStringAsFixed(1)} Mbps' : '-'),
            _kv('Uploaded', _ulBytes > 0 ? _fmtBytes(_ulBytes) : '-'),
          ],
        ),
      ),
    );
  }

  Widget _buildResultsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Results', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            _kv('Started', _startedAt != null ? _startedAt!.toLocal().toString() : '-'),
            _kv('Finish', (!_running && _startedAt != null) ? DateTime.now().toLocal().toString() : '-'),
            if (_downloadUrl != 'Auto') _kv('Download URL', _downloadUrl),
            if (_uploadUrl != 'Auto') _kv('Upload URL', _uploadUrl),
          ],
        ),
      ),
    );
  }

  Widget _kv(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 140, child: Text(k)),
          Expanded(child: Text(v, textAlign: TextAlign.right)),
        ],
      ),
    );
  }

  // ---------------- Control ----------------

  void _cancelTest() {
    _cancelled = true;
    _watchdog?.cancel();
    if (mounted) {
      setState(() {
        _phase = 'Cancelled';
        _running = false;
      });
    }
    _showSnack('Test cancelled');
  }

  void _resetAll() {
    setState(() {
      _running = false;
      _cancelled = false;
      _phase = 'Idle';
      _server = 'Auto';
      _downloadUrl = 'Auto';
      _uploadUrl = 'Auto';
      _statusNote = null;
      _pingMedian = 0;
      _pingP95 = 0;
      _pingJitter = 0;
      _dlMbps = 0;
      _dlBytes = 0;
      _ulMbps = 0;
      _ulBytes = 0;
      _startedAt = null;
    });
  }

  Future<void> _runTest() async {
    _resetAll();
    _cancelled = false;
    _startedAt = DateTime.now();

    setState(() {
      _running = true;
      _phase = 'Connectivity check';
      _statusNote = null;
    });

    // Global watchdog
    _watchdog?.cancel();
    _watchdog = Timer(_globalWatchdog, () {
      if (!_cancelled) {
        _cancelled = true;
        if (mounted) {
          setState(() {
            _phase = 'Timed out';
            _running = false;
          });
        }
        _showSnack('Global timeout');
      }
    });

    try {
      // 0) Connectivity preflight (fast)
      final hasNet = await _connectivityPreflight();
      if (!hasNet) {
        throw Exception('No internet (preflight failed)');
      }

      // 1) Download server select (GET Range probe, best RTT)
      setState(() => _phase = 'Selecting server');
      final dlUrl = await _selectDownloadUrl();
      if (_cancelled) return;
      if (dlUrl == null) {
        throw Exception('No download server reachable');
      }
      _downloadUrl = dlUrl;
      _server = Uri.parse(dlUrl).host;
      setState(() {});

      // 2) Upload sink select (small POST probe)
      final upUrl = await _selectUploadUrl();
      if (_cancelled) return;
      if (upUrl == null) {
        throw Exception('No upload sink reachable');
      }
      _uploadUrl = upUrl;
      setState(() {});

      // 3) Ping (HTTP TTFB)
      setState(() => _phase = 'Ping');
      final ping = await _runPing(serverUrlForPing: dlUrl, samples: pingSamples, interval: pingInterval);
      if (_cancelled) return;
      setState(() {
        _pingMedian = ping.medianMs;
        _pingP95 = ping.p95Ms;
        _pingJitter = ping.jitterMs;
      });

      // 4) Download
      setState(() {
        _phase = 'Download';
        _statusNote = null;
      });
      final dl = await _runDownload(
        url: dlUrl,
        parallel: dlParallel,
        duration: dlDuration,
        warmup: dlWarmup,
        maxBytes: dlMaxBytes,
      );
      if (_cancelled) return;
      setState(() {
        _dlMbps = dl.mbps;
        _dlBytes = dl.bytes;
      });

      // 5) Upload
      setState(() {
        _phase = 'Upload';
        _statusNote = null;
      });
      final ul = await _runUpload(
        url: upUrl,
        parallel: ulParallel,
        duration: ulDuration,
        warmup: ulWarmup,
        maxBytes: ulMaxBytes,
      );
      if (_cancelled) return;
      setState(() {
        _ulMbps = ul.mbps;
        _ulBytes = ul.bytes;
      });

      if (!_cancelled) {
        setState(() {
          _phase = 'Done';
          _running = false;
        });
      }
    } catch (e) {
      if (!_cancelled && mounted) {
        setState(() {
          _phase = 'Error';
          _statusNote = e.toString();
          _running = false;
        });
        _showSnack('Speed test error: $e');
      }
    } finally {
      _watchdog?.cancel();
    }
  }

  void _showSnack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ---------------- Connectivity preflight ----------------

  Future<bool> _connectivityPreflight() async {
    for (final u in _connectivityUrls) {
      if (_cancelled) return false;
      try {
        final client = _newClient();
        try {
          final uri = _withBuster(Uri.parse(u));
          // Some endpoints dislike HEAD; use GET but ignore body.
          final req = await client.getUrl(uri).timeout(_preflightTimeout);
          req.persistentConnection = false;
          req.headers.set(HttpHeaders.userAgentHeader, 'SpeedTest/1.0');
          final resp = await req.close().timeout(_preflightTimeout);
          await resp.drain().timeout(_preflightTimeout);
          client.close(force: true);
          if (resp.statusCode == 204 || resp.statusCode == 200) return true;
        } finally {
          client.close(force: true);
        }
      } catch (_) {
        // try next
      }
    }
    return false;
  }

  // ---------------- Server selection ----------------

  Future<String?> _selectDownloadUrl() async {
    final probes = <_ProbeResult>[];

    for (final raw in _downloadCandidates) {
      if (_cancelled) return null;
      final url = _addQuery(raw, {'rangeprobe': '1'});
      try {
        final rtt = await _rangeProbe(url);
        probes.add(_ProbeResult(url: raw, rttMs: rtt));
      } catch (_) {
        // ignore this candidate
      }
    }

    if (probes.isEmpty) return null;

    probes.sort((a, b) => a.rttMs.compareTo(b.rttMs));
    // Pick the lowest RTT candidate, but use the original URL (without rangeprobe suffix)
    return probes.first.url;
  }

  Future<double> _rangeProbe(String baseUrl) async {
    final client = _newClient();
    final sw = Stopwatch()..start();
    try {
      final uri = _withBuster(Uri.parse(baseUrl));
      final req = await client.getUrl(uri).timeout(_perRequestTimeout);
      req.persistentConnection = false;
      req.headers.set(HttpHeaders.userAgentHeader, 'SpeedTest/1.0');
      req.headers.set(HttpHeaders.rangeHeader, 'bytes=0-0'); // minimal payload
      final resp = await req.close().timeout(_perRequestTimeout);
      await resp.drain().timeout(_perRequestTimeout);
      sw.stop();
      return sw.elapsedMicroseconds / 1000.0;
    } finally {
      client.close(force: true);
    }
  }

  Future<String?> _selectUploadUrl() async {
    for (final raw in _uploadCandidates) {
      if (_cancelled) return null;
      try {
        final ok = await _uploadPreflight(raw);
        if (ok) return raw;
      } catch (_) {
        // try next
      }
    }
    return null;
  }

  Future<bool> _uploadPreflight(String baseUrl) async {
    final client = _newClient();
    try {
      final uri = _withBuster(Uri.parse(baseUrl));
      final req = await client.postUrl(uri).timeout(_perRequestTimeout);
      req.persistentConnection = false;
      req.headers.set(HttpHeaders.userAgentHeader, 'SpeedTest/1.0');
      req.headers.contentType = ContentType('application', 'octet-stream');
      req.bufferOutput = false;
      await req.addStream(Stream.value(List<int>.filled(1024, 0))).timeout(_perRequestTimeout);
      final resp = await req.close().timeout(_perRequestTimeout);
      await resp.drain().timeout(_perRequestTimeout);
      return resp.statusCode >= 200 && resp.statusCode < 400;
    } finally {
      client.close(force: true);
    }
  }

  // ---------------- Ping ----------------

  Future<_PingStats> _runPing({
    required String serverUrlForPing,
    required int samples,
    required Duration interval,
  }) async {
    final uri = Uri.parse(serverUrlForPing);
    final pingUri = Uri(scheme: uri.scheme, host: uri.host, port: uri.port, path: '/');
    final latencies = <double>[];

    for (int i = 0; i < samples; i++) {
      if (_cancelled) break;

      final client = _newClient();
      final sw = Stopwatch()..start();
      try {
        final req = await client.getUrl(_withBuster(pingUri)).timeout(_perRequestTimeout);
        req.persistentConnection = false;
        req.headers.set(HttpHeaders.userAgentHeader, 'SpeedTest/1.0');
        final resp = await req.close().timeout(_perRequestTimeout);
        await resp.drain(const <int>[]).timeout(_perRequestTimeout);
        sw.stop();
        latencies.add(sw.elapsedMicroseconds / 1000.0);
      } catch (_) {
        latencies.add(1000.0); // penalize as 1s
      } finally {
        client.close(force: true);
      }

      // live update
      if (mounted) {
        final stats = _calcPingStats(latencies);
        setState(() {
          _pingMedian = stats.medianMs;
          _pingP95 = stats.p95Ms;
          _pingJitter = stats.jitterMs;
        });
      }

      await Future.delayed(interval);
    }

    return _calcPingStats(latencies);
  }

  _PingStats _calcPingStats(List<double> list) {
    if (list.isEmpty) return const _PingStats(0, 0, 0);
    final sorted = List<double>.from(list)..sort();
    final n = sorted.length;
    final median = n.isOdd ? sorted[n ~/ 2] : (sorted[n ~/ 2 - 1] + sorted[n ~/ 2]) / 2.0;
    final p95 = sorted[(0.95 * (n - 1)).round()];
    // RMS jitter approximation
    final mean = list.reduce((a, b) => a + b) / n;
    final variance = list.map((x) => pow(x - mean, 2)).reduce((a, b) => a + b) / n;
    final jitter = sqrt(variance);
    return _PingStats(median, p95, jitter);
  }

  // ---------------- Download ----------------

  Future<_Throughput> _runDownload({
    required String url,
    required int parallel,
    required Duration duration,
    required Duration warmup,
    required int maxBytes,
  }) async {
    final start = DateTime.now();
    final deadline = start.add(duration);
    final warmupEnd = start.add(warmup);

    int totalBytes = 0;
    int windowBytes = 0;
    DateTime windowStart = DateTime.now();

    // This flag is set when time/size goals are met OR cancelled.
    bool shouldStop = false;

    Future<void> worker(int id) async {
      while (!_cancelled && !shouldStop) {
        final client = _newClient();
        try {
          final uri = _withBuster(Uri.parse(url), extra: {'w': '$id'});
          final req = await client.getUrl(uri).timeout(_perRequestTimeout);
          req.persistentConnection = false;
          req.headers.set(HttpHeaders.userAgentHeader, 'SpeedTest/1.0');
          final resp = await req.close().timeout(_perRequestTimeout);

          // Stream with stall-timeout; on stall, error triggers restart of worker loop.
          final stream = resp.timeout(
            _stallTimeout,
            onTimeout: (sink) => sink.addError(TimeoutException('download stall')),
          );

          await for (final chunk in stream) {
            if (_cancelled) break;

            final len = chunk.length;
            totalBytes += len;
            if (DateTime.now().isAfter(warmupEnd)) {
              windowBytes += len;
            }

            final now = DateTime.now();
            final reachedTime = now.isAfter(deadline);
            final reachedBytes = totalBytes >= maxBytes;

            // Live UI update every ~200ms
            final dt = now.difference(windowStart).inMilliseconds;
            if (dt >= 200 && windowBytes > 0) {
              final seconds = dt / 1000.0;
              final mbps = (windowBytes * 8) / seconds / 1e6;
              if (mounted) {
                setState(() {
                  _dlMbps = mbps;
                  _dlBytes = totalBytes;
                });
              }
              windowBytes = 0;
              windowStart = now;
            }

            if (reachedTime || reachedBytes) {
              shouldStop = true;
              break;
            }
          }
        } on TimeoutException {
          // Stall or op timeout: restart this worker (unless deadline reached)
          if (DateTime.now().isAfter(deadline)) {
            shouldStop = true;
          }
        } catch (_) {
          // Ignore and retry with next loop until deadline.
          if (DateTime.now().isAfter(deadline)) {
            shouldStop = true;
          }
        } finally {
          client.close(force: true);
        }
      }
    }

    // Start workers
    final futures = <Future<void>>[];
    for (int i = 0; i < parallel; i++) {
      futures.add(worker(i));
    }
    await Future.wait(futures);

    // Average Mbps over post-warmup window (approx)
    final effectiveStart = warmupEnd.isAfter(deadline) ? start : warmupEnd;
    final effectiveEnd = DateTime.now().isAfter(deadline) ? deadline : DateTime.now();
    final seconds = max(0.001, effectiveEnd.difference(effectiveStart).inMilliseconds / 1000.0);
    final mbpsAvg = (totalBytes * 8) / seconds / 1e6;

    if (totalBytes == 0) {
      setState(() => _statusNote = 'Download received 0 bytes');
    }

    return _Throughput(bytes: totalBytes, mbps: mbpsAvg);
  }

  // ---------------- Upload ----------------

  Future<_Throughput> _runUpload({
    required String url,
    required int parallel,
    required Duration duration,
    required Duration warmup,
    required int maxBytes,
  }) async {
    final start = DateTime.now();
    final deadline = start.add(duration);
    final warmupEnd = start.add(warmup);

    int totalBytes = 0;
    int windowBytes = 0;
    DateTime windowStart = DateTime.now();

    bool shouldStop = false;
    final chunk = List<int>.filled(ulChunkSize, 0);

    Future<void> worker(int id) async {
      while (!_cancelled && !shouldStop) {
        final client = _newClient();
        try {
          final uri = _withBuster(Uri.parse(url), extra: {'w': '$id'});
          final req = await client.postUrl(uri).timeout(_perRequestTimeout);
          req.persistentConnection = false;
          req.headers.set(HttpHeaders.userAgentHeader, 'SpeedTest/1.0');
          req.headers.contentType = ContentType('application', 'octet-stream');
          req.bufferOutput = false;

          while (!_cancelled && !shouldStop) {
            // write one chunk with timeout
            await req.addStream(Stream.value(chunk)).timeout(_perRequestTimeout);

            totalBytes += chunk.length;
            if (DateTime.now().isAfter(warmupEnd)) {
              windowBytes += chunk.length;
            }

            final now = DateTime.now();
            final reachedTime = now.isAfter(deadline);
            final reachedBytes = totalBytes >= maxBytes;

            // Live UI
            final dt = now.difference(windowStart).inMilliseconds;
            if (dt >= 200 && windowBytes > 0) {
              final seconds = dt / 1000.0;
              final mbps = (windowBytes * 8) / seconds / 1e6;
              if (mounted) {
                setState(() {
                  _ulMbps = mbps;
                  _ulBytes = totalBytes;
                });
              }
              windowBytes = 0;
              windowStart = now;
            }

            if (reachedTime || reachedBytes) {
              shouldStop = true;
              break;
            }
          }

          // close request (ignore errors/timeouts here)
          try {
            final resp = await req.close().timeout(_perRequestTimeout);
            await resp.drain().timeout(_perRequestTimeout);
          } catch (_) {}
        } on TimeoutException {
          if (DateTime.now().isAfter(deadline)) {
            shouldStop = true;
          }
        } catch (_) {
          if (DateTime.now().isAfter(deadline)) {
            shouldStop = true;
          }
        } finally {
          client.close(force: true);
        }
      }
    }

    final futures = <Future<void>>[];
    for (int i = 0; i < parallel; i++) {
      futures.add(worker(i));
    }
    await Future.wait(futures);

    final effectiveStart = warmupEnd.isAfter(deadline) ? start : warmupEnd;
    final effectiveEnd = DateTime.now().isAfter(deadline) ? deadline : DateTime.now();
    final seconds = max(0.001, effectiveEnd.difference(effectiveStart).inMilliseconds / 1000.0);
    final mbpsAvg = (totalBytes * 8) / seconds / 1e6;

    if (totalBytes == 0) {
      setState(() => _statusNote = 'Upload sent 0 bytes');
    }

    return _Throughput(bytes: totalBytes, mbps: mbpsAvg);
  }

  // ---------------- Utils ----------------

  HttpClient _newClient() {
    final c = HttpClient();
    c.autoUncompress = false; // measure raw throughput
    c.connectionTimeout = const Duration(seconds: 6);
    c.idleTimeout = const Duration(seconds: 6);
    return c;
  }

  Uri _withBuster(Uri uri, {Map<String, String>? extra}) {
    final q = Map<String, String>.from(uri.queryParameters);
    q['cb'] = DateTime.now().microsecondsSinceEpoch.toString();
    if (extra != null) q.addAll(extra);
    return uri.replace(queryParameters: q);
  }

  String _addQuery(String base, Map<String, String> kv) {
    final uri = Uri.parse(base);
    final q = Map<String, String>.from(uri.queryParameters)..addAll(kv);
    return uri.replace(queryParameters: q).toString();
  }

  String _fmtBytes(int b) {
    if (b < 1024) return '$b B';
    if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(1)} KB';
    return '${(b / (1024 * 1024)).toStringAsFixed(1)} MB';
  }
}

// -------- Helpers --------

class _ProbeResult {
  final String url;
  final double rttMs;
  _ProbeResult({required this.url, required this.rttMs});
}

class _PingStats {
  final double medianMs;
  final double p95Ms;
  final double jitterMs;
  const _PingStats(this.medianMs, this.p95Ms, this.jitterMs);
}

class _Throughput {
  final int bytes;
  final double mbps;
  const _Throughput({required this.bytes, required this.mbps});
}
