import 'dart:async';
import 'package:flutter/material.dart';
import 'package:signal_test_and_measurement/services/bts_info_service.dart';

/// Simple viewer for the live BTS JSON snapshots.
class BtsScreen extends StatefulWidget {
  const BtsScreen({super.key});

  @override
  State<BtsScreen> createState() => _BtsScreenState();
}

class _BtsScreenState extends State<BtsScreen> {
  final _info = BtsInfoService(); // <-- Instance (not static/singleton)
  StreamSubscription<Map<String, dynamic>>? _sub;
  Map<String, dynamic>? _last;

  @override
  void initState() {
    super.initState();
    _info.startListening();
    _sub = _info.getBtsStream().listen((m) {
      setState(() => _last = m);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    _info.stopListening();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final m = _last;
    return Scaffold(
      appBar: AppBar(title: const Text('BTS Live JSON')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: SelectableText(
          m == null ? 'Waiting…' : _pretty(m),
          style: const TextStyle(fontFamily: 'monospace'),
        ),
      ),
    );
  }

  String _pretty(Map<String, dynamic> m) {
    // Minimal pretty-printer without jsonEncode to keep a readable, stable order
    final b = StringBuffer();
    m.forEach((k, v) => b.writeln('$k: $v'));
    return b.toString();
  }
}
