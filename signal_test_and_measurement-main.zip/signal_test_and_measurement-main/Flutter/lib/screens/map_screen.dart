import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'package:signal_test_and_measurement/services/database_service.dart';
// Location service + geolocator
import 'package:signal_test_and_measurement/services/location_service.dart';
import 'package:geolocator/geolocator.dart';

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});
  @override
  State<MapScreen> createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  // Services
  final _db = DatabaseService();
  final _loc = LocationService(); // user location helper

  // Map
  GoogleMapController? _map;
  static const LatLng _fallbackCenter = LatLng(52.520008, 13.404954);
  CameraPosition _initial = const CameraPosition(target: _fallbackCenter, zoom: 12);

  // Keep last user position to animate after map is created
  LatLng? _lastUserPos;

  // Marker state
  final Map<String, Marker> _dbMarkers = {}; // all markers with coordinates
  String? _currentRedKey;                    // exactly one red: newest last_seen

  // Cache RAT/mode by key to set colors without extra DB reads
  final Map<String, String> _ratByKey = {};        // "LTE" or "NR"
  final Map<String, String?> _nrModeByKey = {};    // "NSA"/"SA"/null

  // Periodic check (every 2 s)
  Timer? _timer;

  // UI state
  bool _loading = true;
  String? _error;

  // Table
  List<Map<String, dynamic>> _cells = [];
  bool _cellsSheetOpen = false;

  // Table width
  double get _tableWidth =>
      56 + 90 + 60 + 72 + 72 + 72 + 100 + 90 + 90 + 130 + 120;

  @override
  void initState() {
    super.initState();
    _loadDbMarkers().then((_) {
      _refreshCurrentRed(); // set immediately once
      _timer = Timer.periodic(const Duration(seconds: 2), (_) => _refreshCurrentRed());
    });
    // Try to center on user as soon as possible
    _centerOnUser();
  }

  @override
  void dispose() {
    _timer?.cancel();
    _map?.dispose();
    super.dispose();
  }

  // ----------------- Initial marker load (coordinates) -----------------
  Future<void> _loadDbMarkers() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await _db.cellsWithCoords(limit: 2000);

      // 1) Collect all NSA anchors so we can hide LTE at the same anchor.
      final nsaAnchors = <String>{};
      for (final r in rows) {
        final rat = ((r['rat'] ?? 'LTE') as String).toUpperCase();
        final mode = (r['nr_mode'] as String?)?.toUpperCase();
        if (rat == 'NR' && mode == 'NSA') {
          final anchor = _anchorFromRow(r) ?? _parseAnchorFromKey(r['key'] as String?);
          if (anchor != null) nsaAnchors.add(anchor);
        }
      }

      // 2) Build markers, skipping LTE rows that share an anchor with an NSA row.
      _dbMarkers.clear();
      _ratByKey.clear();
      _nrModeByKey.clear();

      for (final r in rows) {
        final key = (r['key'] ?? '') as String;
        final lat = r['lat'], lon = r['lon'];
        if (lat is! num || lon is! num) continue;

        final ratRaw = ((r['rat'] ?? 'LTE') as String).toUpperCase();
        final rat = (ratRaw == 'NR') ? 'NR' : 'LTE';
        final mode = (r['nr_mode'] as String?)?.toUpperCase(); // "NSA"/"SA"/null

        // Dedupe policy:
        // If there exists an NSA row for the same anchor, hide the LTE marker at that anchor.
        if (rat == 'LTE') {
          final anchor = _anchorFromRow(r) ?? _parseAnchorFromKey(key);
          if (anchor != null && nsaAnchors.contains(anchor)) {
            continue; // skip LTE marker at NSA anchor
          }
        }

        _ratByKey[key] = rat;
        _nrModeByKey[key] = mode;

        final pos = LatLng(lat.toDouble(), lon.toDouble());
        final isHot = (key == _currentRedKey);
        _dbMarkers[key] = _buildMarkerForKey(key, pos, hot: isHot);
      }

      // Fall back to first marker position if we don't have a user fix yet.
      if (_dbMarkers.isNotEmpty && _map == null && _lastUserPos == null) {
        _initial = CameraPosition(target: _dbMarkers.values.first.position, zoom: 14);
      }
      setState(() => _loading = false);
    } catch (e) {
      setState(() {
        _loading = false;
        _error = e.toString();
      });
    }
  }

  // ----------------- Determine newest cell & colorize -----------------
  Future<void> _refreshCurrentRed() async {
    try {
      // newest row (ORDER BY last_seen DESC LIMIT 1)
      final rows = await _db.latestCells(limit: 1);
      if (rows.isEmpty) return;

      final newKey = rows.first['key'] as String?;
      if (newKey == null) return;

      if (newKey != _currentRedKey) {
        _currentRedKey = newKey;

        // Recolor markers (positions unchanged)
        final newMarkers = <String, Marker>{};
        _dbMarkers.forEach((key, old) {
          final hot = (key == _currentRedKey);
          newMarkers[key] = _buildMarkerForKey(key, old.position, hot: hot);
        });

        if (mounted) {
          setState(() {
            _dbMarkers
              ..clear()
              ..addAll(newMarkers);
          });
        }
      }
    } catch (_) {
      // silently ignore
    }
  }

  // Decide marker hue:
  // - Serving (hot): RED
  // - Recorded LTE:  GREEN
  // - Recorded NR:   BLUE variants by nr_mode:
  //     * NSA -> Azure (light blue)
  //     * SA  -> Blue  (dark blue)
  double _hueForKey(String key, bool hot) {
    if (hot) return BitmapDescriptor.hueRed;
    final rat = _ratByKey[key]?.toUpperCase() ?? 'LTE';
    if (rat == 'NR') {
      final mode = _nrModeByKey[key]?.toUpperCase();
      if (mode == 'NSA') return BitmapDescriptor.hueAzure; // light blue
      return BitmapDescriptor.hueBlue;                      // SA / default NR
    }
    return BitmapDescriptor.hueGreen; // LTE
  }

  Marker _buildMarkerForKey(String key, LatLng pos, {required bool hot}) {
    return Marker(
      markerId: MarkerId('db_$key'),
      position: pos,
      infoWindow: InfoWindow(
        title: hot ? 'Serving cell' : 'Recorded cell',
        snippet: 'Tap marker for full details',
      ),
      zIndex: hot ? 2 : 1,
      icon: BitmapDescriptor.defaultMarkerWithHue(_hueForKey(key, hot)),
      onTap: () => _openDetailsForKey(key),
    );
  }

  // ----------------- Center on user -----------------
  Future<void> _centerOnUser() async {
    try {
      await _loc.ensurePermissions(); // prompt user if needed

      // Try high-accuracy current position; fall back to last known.
      Position? pos;
      try {
        pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.high,
        ).timeout(const Duration(seconds: 3));
      } catch (_) {
        pos = await Geolocator.getLastKnownPosition();
      }
      if (pos == null) return;

      final target = LatLng(pos.latitude, pos.longitude);
      _lastUserPos = target;

      if (!mounted) return;

      if (_map != null) {
        await _map!.animateCamera(
          CameraUpdate.newCameraPosition(CameraPosition(target: target, zoom: 15)),
        );
      } else {
        // If map not created yet, set initial camera so it opens on user.
        setState(() {
          _initial = CameraPosition(target: target, zoom: 15);
        });
      }
    } catch (_) {
      // keep fallback center (Berlin) silently
    }
  }

  // ----------------- Detail bottom sheet -----------------
  Future<void> _openDetailsForKey(String key) async {
    try {
      final row = await _db.rowByKey(key);
      if (row == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('No DB row for $key')),
        );
        return;
      }

      String rat = (row['rat'] as String?) ?? 'LTE';
      final nrMode = (row['nr_mode'] as String?)?.toUpperCase();
      // Display RAT as three-state label for clarity.
      String displayRat;
      if (rat.toUpperCase() == 'NR') {
        displayRat = (nrMode == 'NSA') ? '5G NSA' : '5G SA';
      } else {
        displayRat = 'LTE';
      }

      final cid = row['cid'];
      final nci = row['nci'];
      final mcc = row['mcc'];
      final mnc = row['mnc'];
      final tac = row['tac'];
      final pci = row['pci'];
      final earfcn = row['earfcn'];
      final nrarfcn = row['nrarfcn'];
      final rsrp = row['rsrp'];
      final rsrq = row['rsrq'];
      final sinr = row['sinr'];
      final lat = row['lat'];
      final lon = row['lon'];
      final ts = row['last_seen'];

      String idStr = (rat.toUpperCase() == 'NR') ? 'NCI ${nci ?? '-'}' : 'CID ${cid ?? '-'}';

      // --- Frequency string with NSA fallback to LTE EARFCN ---
      String arfcnStr() {
        final ratU = rat.toUpperCase();
        final mode = (row['nr_mode'] as String?)?.toUpperCase();
        int? _toInt(dynamic v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}');

        if (ratU == 'NR') {
          final nr = _toInt(nrarfcn);
          final lte = _toInt(earfcn);

          if (mode == 'NSA') {
            // Prefer NRARFCN; fallback to LTE EARFCN (~MHz) for NSA
            if (nr != null) return 'NRARFCN $nr';
            if (lte != null) {
              final mhz = _lteDlFreqFromEarfcn(lte);
              return mhz == null ? 'EARFCN $lte' : 'EARFCN $lte (~${mhz.toStringAsFixed(1)} MHz)';
            }
            return '-';
          } else {
            // SA
            return (nr == null) ? '-' : 'NRARFCN $nr';
          }
        } else {
          final lte = (earfcn is num) ? earfcn.toInt() : int.tryParse('${earfcn ?? ''}');
          if (lte == null) return '-';
          final mhz = _lteDlFreqFromEarfcn(lte);
          return mhz == null ? 'EARFCN $lte' : 'EARFCN $lte (~${mhz.toStringAsFixed(1)} MHz)';
        }
      }

      String num1(dynamic v, {int frac = 1}) {
        if (v == null) return '-';
        final d = (v is num) ? v.toDouble() : double.tryParse('$v');
        return d == null ? '-' : d.toStringAsFixed(frac);
      }

      String tsFmt(dynamic t) {
        if (t is! num) return '-';
        final dt = DateTime.fromMillisecondsSinceEpoch(t.toInt()).toLocal();
        String two(int x) => x.toString().padLeft(2, '0');
        return '${dt.year}-${two(dt.month)}-${two(dt.day)} '
            '${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
      }

      await showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        backgroundColor: Theme.of(context).colorScheme.surface,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
        ),
        builder: (_) {
          return DraggableScrollableSheet(
            expand: false,
            initialChildSize: 0.55,
            minChildSize: 0.35,
            maxChildSize: 0.95,
            builder: (_, controller) {
              return ListView(
                controller: controller,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                children: [
                  Row(
                    children: [
                      Text(
                        (rat.toUpperCase() == 'NR')
                            ? (nrMode == 'NSA' ? '5G NSA Cell' : '5G SA Cell')
                            : 'LTE Cell',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      const Spacer(),
                      if (lat is num && lon is num)
                        IconButton(
                          tooltip: 'Center on marker',
                          icon: const Icon(Icons.center_focus_strong),
                          onPressed: () {
                            Navigator.pop(context);
                            _map?.animateCamera(
                              CameraUpdate.newCameraPosition(
                                CameraPosition(
                                  target: LatLng(lat.toDouble(), lon.toDouble()),
                                  zoom: 15,
                                ),
                              ),
                            );
                          },
                        ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  _kv('ID', idStr),
                  _kv('RAT', displayRat), // show three-state label
                  _kv('MCC/MNC', '${mcc ?? '-'} / ${mnc ?? '-'}'),
                  _kv('TAC', '${tac ?? '-'}'),
                  _kv('PCI', '${pci ?? '-'}'),
                  _kv('Frequency', arfcnStr()),
                  const Divider(),
                  _kv('RSRP', '${num1(rsrp)} dBm'),
                  _kv('RSRQ', '${num1(rsrq)} dB'),
                  _kv('SINR', '${num1(sinr)} dB'),
                  const Divider(),
                  _kv('Latitude', (lat is num) ? lat.toStringAsFixed(6) : '-'),
                  _kv('Longitude', (lon is num) ? lon.toStringAsFixed(6) : '-'),
                  _kv('Last seen', tsFmt(ts)),
                ],
              );
            },
          );
        },
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Details failed: $e')),
      );
    }
  }

  Widget _kv(String k, String v) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(width: 120, child: Text(k)),
          Expanded(child: Text(v, textAlign: TextAlign.right)),
        ],
      ),
    );
  }

  // ----------------- Helpers -----------------
  /// Compute LTE DL frequency (MHz) from EARFCN if in known band set.
  double? _lteDlFreqFromEarfcn(int earfcn) {
    final bands = <_LteBand>[
      _LteBand('B1', 0, 599, 0, 2110.0),
      _LteBand('B3', 1200, 1949, 1200, 1805.0),
      _LteBand('B7', 2750, 3449, 2750, 2620.0),
      _LteBand('B8', 3450, 3799, 3450, 925.0),
      _LteBand('B20', 6150, 6449, 6150, 791.0),
      _LteBand('B28', 9210, 9659, 9210, 758.0),
    ];
    for (final b in bands) {
      if (earfcn >= b.min && earfcn <= b.max) {
        return b.fLow + 0.1 * (earfcn - b.nOffs);
      }
    }
    return null;
  }

  /// Try to construct the anchor identifier from row fields (preferred).
  /// Returns "<mcc>-<mnc>-<tac>:<cid>" or null if not all present.
  String? _anchorFromRow(Map<String, dynamic> r) {
    final mcc = r['mcc'], mnc = r['mnc'], tac = r['tac'], cid = r['cid'];
    if (mcc is num && mnc is num && tac is num && cid is num) {
      return '${mcc.toInt()}-${mnc.toInt()}-${tac.toInt()}:${cid.toInt()}';
    }
    return null;
  }

  /// Parse anchor from a DB key when possible.
  /// Supports keys like "NRNSA:<anchor>" and "LTE:<mcc>-<mnc>-<tac>:<cid>".
  String? _parseAnchorFromKey(String? key) {
    if (key == null || key.isEmpty) return null;
    if (key.startsWith('NRNSA:')) {
      return key.substring('NRNSA:'.length);
    }
    if (key.startsWith('LTE:')) {
      final rest = key.substring('LTE:'.length);
      // If LTE key is only "LTE:<cid>" there is no anchor info to parse.
      if (rest.contains('-') && rest.contains(':')) {
        return rest; // already "<mcc>-<mnc>-<tac>:<cid>"
      }
    }
    return null;
  }

  // ----------------- Bottom sheet table -----------------
  Future<void> _openCellsSheet() async {
    try {
      _cells = await _db.latestCells(limit: 500);
    } catch (e) {
      _cells = [];
      _error = e.toString();
    }
    _cellsSheetOpen = true;
    if (mounted) setState(() {});

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Theme.of(context).colorScheme.surface,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (ctx) {
        return DraggableScrollableSheet(
          initialChildSize: 0.6,
          minChildSize: 0.3,
          maxChildSize: 0.95,
          expand: false,
          builder: (_, controller) {
            return Column(
              children: [
                const SizedBox(height: 8),
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.black26,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      const Text('Recorder Cells (latest)',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      const Spacer(),
                      IconButton(
                        tooltip: 'Refresh',
                        icon: const Icon(Icons.refresh),
                        onPressed: () async {
                          final rows = await _db.latestCells(limit: 500);
                          if (mounted) setState(() => _cells = rows);
                        },
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1),
                Expanded(
                  child: SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: SizedBox(
                      width: _tableWidth,
                      child: Column(
                        children: [
                          _headerRow(),
                          const Divider(height: 1),
                          Expanded(
                            child: ListView.builder(
                              controller: controller,
                              itemCount: _cells.length,
                              itemBuilder: (_, i) => _cellRow(_cells[i]),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        );
      },
    );

    _cellsSheetOpen = false;
  }

  Widget _headerRow() {
    Text _h(String t) => Text(
      t,
      style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
    );
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      child: SizedBox(
        width: _tableWidth,
        child: Row(
          children: [
            _w(56, _h('RAT')),
            _w(90, _h('ID')),
            _w(60, _h('PCI')),
            _w(72, _h('RSRP')),
            _w(72, _h('RSRQ')),
            _w(72, _h('SINR')),
            _w(100, _h('Last seen')),
            _w(90, _h('Lat')),
            _w(90, _h('Lon')),
            _w(130, _h('ARFCN')),
            _w(120, _h('Key')),
          ],
        ),
      ),
    );
  }

  Widget _cellRow(Map<String, dynamic> r) {
    String rawRat = (r['rat'] ?? '-') as String;
    final nrMode = (r['nr_mode'] as String?)?.toUpperCase();
    // Display label: LTE / 5G NSA / 5G SA
    String rat = (rawRat.toUpperCase() == 'NR')
        ? (nrMode == 'NSA' ? '5G NSA' : '5G SA')
        : 'LTE';

    final cid = r['cid'];
    final nci = r['nci'];
    final pci = r['pci'];
    final rsrp = r['rsrp'];
    final rsrq = r['rsrq'];
    final sinr = r['sinr'];
    final lat = r['lat'];
    final lon = r['lon'];
    final ts = r['last_seen'];
    final earfcn = r['earfcn'];
    final nrarfcn = r['nrarfcn'];
    final key = (r['key'] ?? '') as String;

    String id = '-';
    if (rawRat.toUpperCase() == 'NR') {
      id = (nci == null) ? '-' : '$nci';
    } else {
      id = (cid == null) ? '-' : '$cid';
    }

    String numFmt(dynamic v, {int frac = 1}) {
      if (v == null) return '-';
      final n = (v is num) ? v.toDouble() : double.tryParse(v.toString());
      return n == null ? '-' : n.toStringAsFixed(frac);
    }

    String tsFmt(dynamic t) {
      if (t is! num) return '-';
      final dt = DateTime.fromMillisecondsSinceEpoch(t.toInt()).toLocal();
      String two(int x) => x.toString().padLeft(2, '0');
      return '${two(dt.hour)}:${two(dt.minute)}:${two(dt.second)}';
    }

    // --- Frequency text with NSA fallback to LTE EARFCN ---
    String arfcnText() {
      final ratU = rawRat.toUpperCase();
      final mode = (r['nr_mode'] as String?)?.toUpperCase();

      int? _toInt(dynamic v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}');
      final nr = _toInt(nrarfcn);
      final lte = _toInt(earfcn);

      if (ratU == 'NR') {
        if (mode == 'NSA') {
          if (nr != null) return 'NRARFCN $nr';
          if (lte != null) {
            final mhz = _lteDlFreqFromEarfcn(lte);
            return mhz == null ? 'EARFCN $lte' : 'EARFCN $lte (~${mhz.toStringAsFixed(1)} MHz)';
          }
          return '-';
        } else {
          return (nr == null) ? '-' : 'NRARFCN $nr';
        }
      } else {
        if (lte == null) return '-';
        final mhz = _lteDlFreqFromEarfcn(lte);
        return mhz == null ? 'EARFCN $lte' : 'EARFCN $lte (~${mhz.toStringAsFixed(1)} MHz)';
      }
    }

    return InkWell(
      onTap: () => _openDetailsForKey(key),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        child: SizedBox(
          width: _tableWidth,
          child: Row(
            children: [
              _w(56, Text(rat)), // three-state label
              _w(90, Text(id)),
              _w(60, Text(pci?.toString() ?? '-')),
              _w(72, Text('${numFmt(rsrp)} dBm')),
              _w(72, Text('${numFmt(rsrq)} dB')),
              _w(72, Text('${numFmt(sinr)} dB')),
              _w(100, Text(tsFmt(ts))),
              _w(90, Text(lat is num ? lat.toStringAsFixed(6) : '-')),
              _w(90, Text(lon is num ? lon.toStringAsFixed(6) : '-')),
              _w(130, Text(arfcnText())),
              _w(120, Text(key, overflow: TextOverflow.ellipsis)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _w(double w, Widget child) => SizedBox(width: w, child: child);

  @override
  Widget build(BuildContext context) {
    final markers = <Marker>{
      ..._dbMarkers.values,
    };

    return Scaffold(
      appBar: AppBar(
        title: const Text('BTS Map'),
        actions: [
          IconButton(
            tooltip: 'Recorder table',
            icon: const Icon(Icons.table_chart),
            onPressed: _openCellsSheet,
          ),
          IconButton(
            tooltip: 'Refresh markers (coords)',
            onPressed: _loadDbMarkers,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: Stack(
        children: [
          GoogleMap(
            initialCameraPosition: _initial,
            onMapCreated: (c) async {
              _map = c;
              // If we already have a user location fix from _centerOnUser(), animate now.
              if (_lastUserPos != null) {
                await _map!.animateCamera(
                  CameraUpdate.newCameraPosition(
                    CameraPosition(target: _lastUserPos!, zoom: 15),
                  ),
                );
              }
            },
            markers: markers,
            myLocationEnabled: true,
            myLocationButtonEnabled: true,
            compassEnabled: true,
            mapToolbarEnabled: false,
          ),
          if (_loading)
            Positioned.fill(
              child: IgnorePointer(
                child: Container(
                  alignment: Alignment.bottomCenter,
                  padding: const EdgeInsets.only(bottom: 16),
                  child: _pill(context,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          SizedBox(
                              height: 18,
                              width: 18,
                              child: CircularProgressIndicator(strokeWidth: 2)),
                          SizedBox(width: 8),
                          Text('Loading BTS database...'),
                        ],
                      )),
                ),
              ),
            ),
          if (_error != null)
            Positioned(
              left: 12,
              right: 12,
              bottom: 16,
              child: _pill(
                context,
                color: Theme.of(context).colorScheme.errorContainer,
                child: Text(
                  _error!,
                  style: TextStyle(
                      color: Theme.of(context).colorScheme.onErrorContainer),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _pill(BuildContext ctx, {required Widget child, Color? color}) {
    final scheme = Theme.of(ctx).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: (color ?? scheme.surface).withOpacity(0.95),
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(blurRadius: 8, spreadRadius: -2, color: Colors.black26)],
      ),
      child: child,
    );
  }
}

class _LteBand {
  final String name;
  final int min, max, nOffs;
  final double fLow;
  _LteBand(this.name, this.min, this.max, this.nOffs, this.fLow);
}
