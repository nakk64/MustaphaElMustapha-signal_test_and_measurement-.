// lib/models/cell_identity.dart
//
// Represents the identity of a serving cell (LTE or NR).
// Includes RAT (LTE/NR), SA/NSA mode, MCC/MNC, and cell IDs.

class CellIdentity {
  final String rat;          // "LTE" or "NR"
  final String? nrMode;      // "SA" or "NSA" (only valid when rat = "NR")

  final int? mcc;
  final int? mnc;

  final int? tac;            // LTE/NR tracking area code
  final int? lac;            // GSM/UMTS location area code

  final int? cid;            // LTE/UMTS/GSM cell ID
  final int? nci;            // 5G NR cell identity

  final int? pci;            // Physical cell ID
  final int? earfcn;         // LTE EARFCN
  final int? nrarfcn;        // NR ARFCN
  final int? band;           // Band number

  CellIdentity({
    required this.rat,
    this.nrMode,
    this.mcc,
    this.mnc,
    this.tac,
    this.lac,
    this.cid,
    this.nci,
    this.pci,
    this.earfcn,
    this.nrarfcn,
    this.band,
  });

  factory CellIdentity.fromJson(Map<String, dynamic> j) {
    return CellIdentity(
      rat: (j['rat'] ?? 'LTE').toString(),
      nrMode: j['nrMode']?.toString(),
      mcc: (j['mcc'] as num?)?.toInt(),
      mnc: (j['mnc'] as num?)?.toInt(),
      tac: (j['tac'] as num?)?.toInt(),
      lac: (j['lac'] as num?)?.toInt(),
      cid: (j['cid'] as num?)?.toInt(),
      nci: (j['nci'] as num?)?.toInt(),
      pci: (j['pci'] as num?)?.toInt(),
      earfcn: (j['earfcn'] as num?)?.toInt(),
      nrarfcn: (j['nrarfcn'] as num?)?.toInt(),
      band: (j['band'] as num?)?.toInt(),
    );
  }
}
