// lib/models/settings_model.dart
//
// Simple data holder for app settings (thresholds + operator).
// This model can be used for serialization or passing around settings.

class SettingsModel {
  final double rsrp;
  final double rsrq;
  final double sinr;
  final int? mcc;
  final int? mnc;

  SettingsModel({
    required this.rsrp,
    required this.rsrq,
    required this.sinr,
    this.mcc,
    this.mnc,
  });
}
