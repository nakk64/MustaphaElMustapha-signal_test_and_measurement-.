// lib/models/bts_kpi.dart
//
// Represents key performance indicators (KPIs) of the serving BTS.
// Values are reported in dBm or dB as appropriate.

class BTSKpi {
  final double? rsrp;   // Reference Signal Received Power (dBm)
  final double? rsrq;   // Reference Signal Received Quality (dB)
  final double? sinr;   // Signal-to-Interference-plus-Noise Ratio (dB)
  final double? rssi;   // Received Signal Strength Indicator (dBm)

  BTSKpi({this.rsrp, this.rsrq, this.sinr, this.rssi});

  factory BTSKpi.fromJson(Map<String, dynamic> j) {
    return BTSKpi(
      rsrp: (j['rsrp'] as num?)?.toDouble(),
      rsrq: (j['rsrq'] as num?)?.toDouble(),
      sinr: (j['sinr'] as num?)?.toDouble(),
      rssi: (j['rssi'] as num?)?.toDouble(),
    );
  }
}
