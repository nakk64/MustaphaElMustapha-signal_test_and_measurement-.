// lib/models/cell_key.dart
//
// Normalized key to uniquely identify a cell for lookups.
// Used to query OpenCellID and deduplicate BTS entries.

import 'cell_identity.dart';

class CellKey {
  final int mcc;
  final int mnc;
  final int? tacOrLac;
  final int? cid;  // LTE/UMTS/GSM
  final int? nci;  // 5G NR

  CellKey._(this.mcc, this.mnc, this.tacOrLac, this.cid, this.nci);

  /// Build a normalized CellKey from a [CellIdentity].
  static CellKey? fromIdentity(CellIdentity id) {
    if (id.mcc == null || id.mnc == null) return null;

    // LTE/UMTS/GSM: requires CID + TAC/LAC
    if (id.rat == 'LTE' && id.cid != null && (id.tac != null || id.lac != null)) {
      return CellKey._(id.mcc!, id.mnc!, id.tac ?? id.lac, id.cid, null);
    }

    // NR (5G): requires NCI + TAC
    if (id.rat == 'NR' && id.nci != null && id.tac != null) {
      return CellKey._(id.mcc!, id.mnc!, id.tac, null, id.nci);
    }

    return null; // unsupported or incomplete
  }
}
