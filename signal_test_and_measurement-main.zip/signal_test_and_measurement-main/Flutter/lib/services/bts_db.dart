import 'dart:async';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

class BtsDb {
  BtsDb._();
  static final BtsDb instance = BtsDb._();

  Database? _db;

  Future<Database> get db async {
    if (_db != null) return _db!;
    _db = await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final base = await getDatabasesPath();
    final file = p.join(base, 'bts_v1.db');
    return openDatabase(
      file,
      version: 1,
      onCreate: (Database d, int v) async {
        await d.execute('''
          CREATE TABLE bts_cells (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT NOT NULL UNIQUE,

            rat TEXT,
            nr_mode TEXT,
            mcc INTEGER,
            mnc INTEGER,
            tac INTEGER,
            lac INTEGER,
            cid INTEGER,
            nci INTEGER,
            pci INTEGER,
            earfcn INTEGER,
            nrarfcn INTEGER,

            rsrp REAL,
            rsrq REAL,
            sinr REAL,

            lat REAL,
            lon REAL,

            first_seen INTEGER,
            last_seen  INTEGER,
            samples INTEGER DEFAULT 0
          )
        ''');
        await d.execute('CREATE INDEX IF NOT EXISTS idx_bts_key ON bts_cells(key)');
        await d.execute('CREATE INDEX IF NOT EXISTS idx_bts_last_seen ON bts_cells(last_seen DESC)');
      },
    );
  }

  /// Key with MCC/MNC (+ TAC for LTE) to avoid collisions.
  static String? buildKey(Map<String, Object?> src) {
    final rat = (src['rat'] as String?)?.toUpperCase();
    final mcc = _toInt(src['mcc']) ?? 0;
    final mnc = _toInt(src['mnc']) ?? 0;
    final tac = _toInt(src['tac']) ?? 0;

    if (rat == 'LTE') {
      final cid = _toInt(src['cid']);
      if (cid != null && cid > 0) {
        return 'LTE:$mcc-$mnc-$tac:$cid';
      }
    } else if (rat == 'NR') {
      final nci = _toInt(src['nci']) ?? _toIntFromString(src['nci']);
      if (nci != null && nci > 0) {
        return 'NR:$mcc-$mnc:$nci';
      }
    }
    return null;
  }

  Future<void> upsertSnapshot({
    required Map<String, Object?> snap,
    double? lat,
    double? lon,
  }) async {
    final database = await db;

    final key = buildKey(snap);
    if (key == null) return;

    final now = DateTime.now().millisecondsSinceEpoch;

    final rat     = (snap['rat'] as String?)?.toUpperCase();
    final nrMode  = snap['nrMode'] as String?;
    final mcc     = _toInt(snap['mcc']);
    final mnc     = _toInt(snap['mnc']);
    final tac     = _toInt(snap['tac']);
    final lac     = _toInt(snap['lac']);
    final cid     = _toInt(snap['cid']);
    final nci     = _toInt(snap['nci']) ?? _toIntFromString(snap['nci']);
    final pci     = _toInt(snap['pci']);
    final earfcn  = _toInt(snap['earfcn']);
    final nrarfcn = _toInt(snap['nrarfcn']);

    final rsrp = _toDouble(snap['rsrp']);
    final rsrq = _toDouble(snap['rsrq']);
    final sinr = _toDouble(snap['sinr']);

    // Update (including coordinates only when provided)
    final updated = await database.rawUpdate(
      '''
      UPDATE bts_cells
         SET rat = ?, nr_mode = ?,
             mcc = ?, mnc = ?, tac = ?, lac = ?,
             cid = ?, nci = ?, pci = ?, earfcn = ?, nrarfcn = ?,
             rsrp = ?, rsrq = ?, sinr = ?,
             lat = COALESCE(?, lat),
             lon = COALESCE(?, lon),
             last_seen = ?,
             samples = samples + 1
       WHERE key = ?
      ''',
      <Object?>[
        rat, nrMode,
        mcc, mnc, tac, lac,
        cid, nci, pci, earfcn, nrarfcn,
        rsrp, rsrq, sinr,
        lat, lon,
        now,
        key,
      ],
    );

    if (updated > 0) return;

    // Insert (ignore on conflict — upsert behavior)
    await database.insert(
      'bts_cells',
      <String, Object?>{
        'key': key,
        'rat': rat,
        'nr_mode': nrMode,
        'mcc': mcc,
        'mnc': mnc,
        'tac': tac,
        'lac': lac,
        'cid': cid,
        'nci': nci,
        'pci': pci,
        'earfcn': earfcn,
        'nrarfcn': nrarfcn,
        'rsrp': rsrp,
        'rsrq': rsrq,
        'sinr': sinr,
        'lat': lat,
        'lon': lon,
        'first_seen': now,
        'last_seen': now,
        'samples': 1,
      },
      conflictAlgorithm: ConflictAlgorithm.ignore,
    );
  }

  Future<List<Map<String, Object?>>> listAll() async {
    final database = await db;
    return database.query('bts_cells', orderBy: 'last_seen DESC');
  }

  /// For the map: only rows with coordinates.
  Future<List<Map<String, Object?>>> listAllForMap() async {
    final database = await db;
    return database.query(
      'bts_cells',
      where: 'lat IS NOT NULL AND lon IS NOT NULL',
      orderBy: 'last_seen DESC',
    );
  }

  Future<void> clearAll() async {
    final database = await db;
    await database.delete('bts_cells');
  }

  Future<void> deleteByKey(String key) async {
    final database = await db;
    await database.delete('bts_cells', where: 'key=?', whereArgs: [key]);
  }

  Future<void> close() async {
    final d = _db;
    _db = null;
    if (d != null && d.isOpen) {
      await d.close();
    }
  }
}

int? _toInt(Object? v) {
  if (v == null) return null;
  if (v is int) return v;
  if (v is num) return v.toInt();
  return int.tryParse(v.toString());
}
int? _toIntFromString(Object? v) {
  if (v == null) return null;
  return int.tryParse(v.toString());
}
double? _toDouble(Object? v) {
  if (v == null) return null;
  if (v is double) return v;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString());
}
