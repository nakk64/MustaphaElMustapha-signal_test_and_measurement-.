import 'dart:io';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';

class BtsBgService {
  static const _ch = MethodChannel('bts/db_service');

  /// Start the foreground service (shows a persistent notification).
  static Future<void> ensureStarted() async {
    if (!Platform.isAndroid) return;

    // Android 13+ requires the POST_NOTIFICATIONS runtime permission for foreground notifications.
    try {
      final status = await Permission.notification.status;
      if (!status.isGranted) {
        await Permission.notification.request();
      }
    } catch (_) {
      // Safe to ignore on Android < 13 or if the platform does not expose this permission.
    }

    try {
      await _ch.invokeMethod('start');
    } on PlatformException catch (e) {
    }
  }

  /// Stop the foreground service.
  static Future<void> stop() async {
    if (!Platform.isAndroid) return;
    try {
      await _ch.invokeMethod('stop');
    } catch (_) {}
  }
}
