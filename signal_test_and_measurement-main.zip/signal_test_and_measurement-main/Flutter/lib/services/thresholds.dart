class Thresholds {
  static const double defaultRsrp = -110.0; // dBm
  static const double defaultRsrq = -14.0;  // dB
  static const double defaultSinr = 0.0;    // dB
}
