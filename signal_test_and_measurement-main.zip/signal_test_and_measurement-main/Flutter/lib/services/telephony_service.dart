import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';

import '../models/bts_kpi.dart';
import '../models/cell_identity.dart';

class TelephonyEvent {
  final BTSKpi kpi;
  final CellIdentity id;
  TelephonyEvent(this.kpi, this.id);
}

class TelephonyService {
  static const _channel = EventChannel('bts/info');

  /// Stream of [TelephonyEvent] objects.
  Stream<TelephonyEvent> kpiStream() {
    return _channel.receiveBroadcastStream().map((event) {
      final map = json.decode(event as String) as Map<String, dynamic>;
      final id = CellIdentity.fromJson(map);
      final kpi = BTSKpi.fromJson(map);
      return TelephonyEvent(kpi, id);
    });
  }
}
