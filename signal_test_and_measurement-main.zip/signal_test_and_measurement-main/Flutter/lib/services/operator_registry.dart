class DeOperator {
  final String id;
  final String label;
  final int mcc;
  final int mnc;
  const DeOperator(this.id, this.label, this.mcc, this.mnc);
}

class OperatorRegistry {
  static const deOperators = <DeOperator>[
    DeOperator('telekom', 'Telekom (262-01)', 262, 1),
    DeOperator('vodafone', 'Vodafone (262-02)', 262, 2),
    DeOperator('o2', 'O2 / Telefónica (262-07)', 262, 7),
    DeOperator('1und1', '1&1 (262-03)', 262, 3),
  ];
}
