import 'package:sqflite/sqflite.dart';

class BtsRepo {
  static Future<int> countCells() async {
    final db = await openDatabase('bts_v1.db');
    final res = await db.rawQuery('SELECT COUNT(*) as c FROM bts_cells');
    final c = (res.first['c'] as int?) ?? 0;
    await db.close();
    return c;
  }
}
