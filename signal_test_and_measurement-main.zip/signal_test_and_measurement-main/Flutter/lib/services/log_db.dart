import 'dart:async';
import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

/// Minimal projection of your LiveSnapshot (to avoid circular imports).
/// The Logs service only needs a subset to store per-sample/per-session metadata.
class SnapshotLite {
  final String rat; // "LTE" or "NR"
  final String? nrMode; // "SA" or "NSA"
  final int? mcc, mnc, tac, lac, cid, pci, earfcn, nrarfcn, nci;
  final double? rsrp, rsrq, sinr;
  final int? timestamp; // ms since epoch

  SnapshotLite({
    required this.rat,
    this.nrMode,
    this.mcc,
    this.mnc,
    this.tac,
    this.lac,
    this.cid,
    this.pci,
    this.earfcn,
    this.nrarfcn,
    this.nci,
    this.rsrp,
    this.rsrq,
    this.sinr,
    this.timestamp,
  });
}

/// POJO for listing sessions.
class LogSession {
  final int id;
  final int startTs;
  final int? endTs;
  final int sampleCount;
  final String rat;
  final String? nrMode;
  final int? mcc, mnc, cid, pci;

  LogSession({
    required this.id,
    required this.startTs,
    required this.endTs,
    required this.sampleCount,
    required this.rat,
    this.nrMode,
    this.mcc,
    this.mnc,
    this.cid,
    this.pci,
  });
}

class LogDb {
  LogDb._();
  static final LogDb instance = LogDb._();

  Database? _db;

  /// Open or create the logs database.
  Future<void> init() async {
    if (_db != null) return;

    final databasesPath = await getDatabasesPath();
    final path = p.join(databasesPath, 'logs.db');

    _db = await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        // Ensure foreign keys cascade deletes.
        await db.execute('PRAGMA foreign_keys = ON;');
      },
      onCreate: (db, version) async {
        // Sessions: one row per recording
        await db.execute('''
          CREATE TABLE sessions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            start_ts INTEGER NOT NULL,
            end_ts INTEGER,
            rat TEXT NOT NULL,
            nr_mode TEXT,
            mcc INTEGER, mnc INTEGER, tac INTEGER, lac INTEGER,
            cid INTEGER, nci INTEGER, pci INTEGER,
            earfcn INTEGER, nrarfcn INTEGER
          )
        ''');

        // Samples: one row per second (or per snapshot)
        await db.execute('''
          CREATE TABLE samples(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id INTEGER NOT NULL,
            ts INTEGER NOT NULL,
            rsrp REAL, rsrq REAL, sinr REAL,
            pci INTEGER, earfcn INTEGER, nrarfcn INTEGER,
            cid INTEGER, nci INTEGER,
            FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE
          )
        ''');

        // Indexes for faster exports and queries
        await db.execute('CREATE INDEX idx_samples_session_ts ON samples(session_id, ts)');
      },
    );
  }

  Database get _requireDb {
    final db = _db;
    if (db == null) {
      throw StateError('LogDb not initialized. Call LogDb.instance.init() first.');
    }
    return db;
  }

  /// Starts a new session using snapshot metadata (RAT, MCC/MNC, cell ids).
  Future<int> startSession(SnapshotLite? meta) async {
    final db = _requireDb;
    final now = DateTime.now().millisecondsSinceEpoch;

    final id = await db.insert('sessions', {
      'start_ts': now,
      'end_ts': null,
      'rat': meta?.rat ?? 'LTE',
      'nr_mode': meta?.nrMode,
      'mcc': meta?.mcc,
      'mnc': meta?.mnc,
      'tac': meta?.tac,
      'lac': meta?.lac,
      'cid': meta?.cid,
      'nci': meta?.nci,
      'pci': meta?.pci,
      'earfcn': meta?.earfcn,
      'nrarfcn': meta?.nrarfcn,
    });

    return id;
    // Note: session is "open" until endSession(...) is called.
  }

  /// Ends a running session by setting the end timestamp.
  Future<void> endSession(int sessionId) async {
    final db = _requireDb;
    final now = DateTime.now().millisecondsSinceEpoch;
    await db.update('sessions', {'end_ts': now}, where: 'id = ?', whereArgs: [sessionId]);
  }

  /// Inserts one live KPI sample for the given session.
  Future<void> insertSample(int sessionId, SnapshotLite snap) async {
    final db = _requireDb;

    final ts = snap.timestamp ?? DateTime.now().millisecondsSinceEpoch;
    await db.insert('samples', {
      'session_id': sessionId,
      'ts': ts,
      'rsrp': snap.rsrp,
      'rsrq': snap.rsrq,
      'sinr': snap.sinr,
      'pci': snap.pci,
      'earfcn': snap.earfcn,
      'nrarfcn': snap.nrarfcn,
      'cid': snap.cid,
      'nci': snap.nci,
    });
  }

  /// Lists sessions with aggregated sample counts.
  Future<List<LogSession>> listSessions() async {
    final db = _requireDb;

    final rows = await db.rawQuery('''
      SELECT s.id, s.start_ts, s.end_ts, s.rat, s.nr_mode, s.mcc, s.mnc, s.cid, s.pci,
             COUNT(x.id) AS sample_count
      FROM sessions s
      LEFT JOIN samples x ON x.session_id = s.id
      GROUP BY s.id
      ORDER BY s.start_ts DESC
    ''');

    return rows.map((r) {
      return LogSession(
        id: (r['id'] as int),
        startTs: (r['start_ts'] as int),
        endTs: r['end_ts'] as int?,
        sampleCount: (r['sample_count'] as int?) ?? 0,
        rat: (r['rat'] as String),
        nrMode: r['nr_mode'] as String?,
        mcc: r['mcc'] as int?,
        mnc: r['mnc'] as int?,
        cid: r['cid'] as int?,
        pci: r['pci'] as int?,
      );
    }).toList();
  }

  /// Deletes a session and all its samples (via FK cascade).
  Future<void> deleteSession(int sessionId) async {
    final db = _requireDb;
    await db.delete('sessions', where: 'id = ?', whereArgs: [sessionId]);
    // samples are deleted automatically because of ON DELETE CASCADE.
  }

  /// Returns all samples for one session (ordered by time).
  Future<List<Map<String, Object?>>> getSamples(int sessionId) async {
    final db = _requireDb;
    return db.query(
      'samples',
      where: 'session_id = ?',
      whereArgs: [sessionId],
      orderBy: 'ts ASC',
    );
  }

  /// Exports a single session to a CSV file and returns the saved file path.
  Future<String> exportSessionCsv(int sessionId) async {
    final db = _requireDb;

    // Read session meta
    final sessionRows = await db.query('sessions', where: 'id = ?', whereArgs: [sessionId], limit: 1);
    if (sessionRows.isEmpty) {
      throw ArgumentError('Session $sessionId not found');
    }
    final s = sessionRows.first;

    // Read samples
    final samples = await getSamples(sessionId);

    // Ensure directory
    final docs = await getApplicationDocumentsDirectory();
    final logsDir = Directory(p.join(docs.path, 'logs'));
    if (!await logsDir.exists()) {
      await logsDir.create(recursive: true);
    }

    // Build filename
    String _fmtTs(int millis) {
      final dt = DateTime.fromMillisecondsSinceEpoch(millis);
      String two(int x) => x.toString().padLeft(2, '0');
      return '${dt.year}${two(dt.month)}${two(dt.day)}-${two(dt.hour)}${two(dt.minute)}${two(dt.second)}';
    }

    final startTs = (s['start_ts'] as int);
    final fileName = 'session_${s['id']}_${_fmtTs(startTs)}.csv';
    final filePath = p.join(logsDir.path, fileName);
    final file = File(filePath);

    // Write CSV header + rows
    final sink = file.openWrite();

    // Meta header (comment lines)
    sink.writeln('# session_id, start_ts, end_ts, rat, nr_mode, mcc, mnc, tac, lac, cid, nci, pci, earfcn, nrarfcn');
    sink.writeln('# ${s['id']},${s['start_ts']},${s['end_ts'] ?? ''},${s['rat']},${s['nr_mode'] ?? ''},'
        '${s['mcc'] ?? ''},${s['mnc'] ?? ''},${s['tac'] ?? ''},${s['lac'] ?? ''},'
        '${s['cid'] ?? ''},${s['nci'] ?? ''},${s['pci'] ?? ''},${s['earfcn'] ?? ''},${s['nrarfcn'] ?? ''}');
    sink.writeln('#');

    // Samples header
    sink.writeln('ts_ms,ts_iso,rsrp,rsrq,sinr,pci,earfcn,nrarfcn,cid,nci');

    for (final row in samples) {
      final ts = (row['ts'] as int);
      final dt = DateTime.fromMillisecondsSinceEpoch(ts).toUtc().toIso8601String();
      final rsrp = row['rsrp'] ?? '';
      final rsrq = row['rsrq'] ?? '';
      final sinr = row['sinr'] ?? '';
      final pci = row['pci'] ?? '';
      final earfcn = row['earfcn'] ?? '';
      final nrarfcn = row['nrarfcn'] ?? '';
      final cid = row['cid'] ?? '';
      final nci = row['nci'] ?? '';
      sink.writeln('$ts,$dt,$rsrp,$rsrq,$sinr,$pci,$earfcn,$nrarfcn,$cid,$nci');
    }

    await sink.flush();
    await sink.close();

    return filePath;
  }

  /// Closes the database (app will close it automatically).
  Future<void> close() async {
    final db = _db;
    if (db != null) {
      await db.close();
      _db = null;
    }
  }
}
