import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart';

class BtsInfoService {
  static final BtsInfoService _instance = BtsInfoService._internal();
  factory BtsInfoService() => _instance;

  BtsInfoService._internal() {
    _ensureNativeStarted();
  }

  static const EventChannel _chan = EventChannel('bts/info');

  StreamSubscription<dynamic>? _nativeSub;
  final StreamController<Map<String, dynamic>> _ctrl =
  StreamController<Map<String, dynamic>>.broadcast();

  Map<String, dynamic>? _last;

  /// --- Compatibility API (for existing screens) ---
  void startListening() => _ensureNativeStarted();

  Stream<Map<String, dynamic>> getBtsStream() => stream();

  void stopListening() {
  }

  /// Public broadcast stream
  Stream<Map<String, dynamic>> stream() {
    _ensureNativeStarted();
    return _ctrl.stream;
  }

  void _ensureNativeStarted() {
    if (_nativeSub != null) return;
    _nativeSub = _chan.receiveBroadcastStream().listen(
          (raw) {
        final Map<String, dynamic>? m = _coerceToMap(raw);
        if (m != null && !_ctrl.isClosed) {
          _last = m;
          _ctrl.add(m);
        }
      },
      onError: (e, st) {
        if (!_ctrl.isClosed) _ctrl.addError(e, st);
      },
      cancelOnError: false,
    );
  }

  Map<String, dynamic>? _coerceToMap(dynamic raw) {
    try {
      if (raw is String) {
        final decoded = jsonDecode(raw);
        if (decoded is Map<String, dynamic>) return decoded;
        if (decoded is Map) {
          return decoded.map((k, v) => MapEntry(k.toString(), v));
        }
      } else if (raw is Map) {
        return raw.map((k, v) => MapEntry(k.toString(), v));
      }
    } catch (_) {
      // ignore malformed frame
    }
    return null;
  }

  /// Call only when the app is truly shutting down.
  Future<void> dispose() async {
    await _nativeSub?.cancel();
    _nativeSub = null;
    await _ctrl.close();
  }
}
