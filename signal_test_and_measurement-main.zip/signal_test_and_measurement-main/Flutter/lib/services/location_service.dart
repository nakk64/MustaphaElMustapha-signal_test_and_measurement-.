import 'package:geolocator/geolocator.dart';

class LocationService {
  /// Request location permissions if not already granted.
  /// Also nudges the user to enable location services if they're turned off.
  Future<void> ensurePermissions() async {
    bool enabled = await Geolocator.isLocationServiceEnabled();
    if (!enabled) {
      await Geolocator.openLocationSettings();
    }

    LocationPermission perm = await Geolocator.checkPermission();
    if (perm == LocationPermission.denied) {
      perm = await Geolocator.requestPermission();
    }
  }

  /// Continuous position updates with high accuracy and no minimum distance filter.
  Stream<Position> positionStream() {
    return Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 0,
      ),
    );
  }
}
