import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'operator_registry.dart';
import 'thresholds.dart';

class SettingsService extends ChangeNotifier {
  // Thresholds
  double rsrpThreshold = Thresholds.defaultRsrp;
  double rsrqThreshold = Thresholds.defaultRsrq;
  double sinrThreshold = Thresholds.defaultSinr;

  // Operator (Germany)
  String? operatorId; // "telekom", "vodafone", "o2", "1und1"
  int? mcc; // usually 262 for Germany
  int? mnc;

  /// Load thresholds and operator from shared_preferences.
  Future<void> load() async {
    final sp = await SharedPreferences.getInstance();

    rsrpThreshold = sp.getDouble('th_rsrp') ?? Thresholds.defaultRsrp;
    rsrqThreshold = sp.getDouble('th_rsrq') ?? Thresholds.defaultRsrq;
    sinrThreshold = sp.getDouble('th_sinr') ?? Thresholds.defaultSinr;

    operatorId = sp.getString('op_id');
    if (operatorId != null) {
      final op = OperatorRegistry.deOperators.firstWhere(
            (o) => o.id == operatorId,
        orElse: () => OperatorRegistry.deOperators.first,
      );
      mcc = op.mcc;
      mnc = op.mnc;
    }

    notifyListeners();
  }

  /// Update thresholds and save them persistently.
  Future<void> setThresholds({double? rsrp, double? rsrq, double? sinr}) async {
    final sp = await SharedPreferences.getInstance();

    if (rsrp != null) {
      rsrpThreshold = rsrp;
      await sp.setDouble('th_rsrp', rsrp);
    }
    if (rsrq != null) {
      rsrqThreshold = rsrq;
      await sp.setDouble('th_rsrq', rsrq);
    }
    if (sinr != null) {
      sinrThreshold = sinr;
      await sp.setDouble('th_sinr', sinr);
    }

    notifyListeners();
  }

  /// Update operator and save it persistently.
  Future<void> setOperator(DeOperator op) async {
    final sp = await SharedPreferences.getInstance();
    operatorId = op.id;
    mcc = op.mcc;
    mnc = op.mnc;
    await sp.setString('op_id', op.id);
    notifyListeners();
  }
}
