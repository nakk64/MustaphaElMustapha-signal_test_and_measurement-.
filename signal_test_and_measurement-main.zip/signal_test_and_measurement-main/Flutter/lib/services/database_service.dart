import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

class DatabaseService {
  Database? _btsDb;

  Future<Database> _openBtsDb({bool readOnly = false}) async {
    if (_btsDb != null && _btsDb!.isOpen) {
      try {
        await _btsDb!.rawQuery('SELECT 1');
        return _btsDb!;
      } catch (_) {
        try { await _btsDb!.close(); } catch (_) {}
        _btsDb = null;
      }
    }

    final dir = await getDatabasesPath();
    final file = p.join(dir, 'bts_v1.db');

    final exists = await databaseFactory.databaseExists(file);
    if (!exists) {
      throw StateError(
        'bts_v1.db not found. Start the foreground recorder (notification visible) '
            'and grant all permissions. Once it writes, the DB appears here.',
      );
    }

    _btsDb = await openDatabase(
      file,
      readOnly: readOnly,
      singleInstance: true,
      onConfigure: (db) async {
        try { await db.execute('PRAGMA journal_mode=DELETE'); } catch (_) {}
        try { await db.execute('PRAGMA synchronous=NORMAL'); } catch (_) {}
        try { await db.execute('PRAGMA busy_timeout=3000'); } catch (_) {}
      },
    );

    try {
      await _btsDb!.rawQuery('SELECT 1');
    } catch (e) {
      try { await _btsDb!.close(); } catch (_) {}
      _btsDb = null;
      rethrow;
    }

    return _btsDb!;
  }

  // ---------- READ QUERIES ----------
  Future<List<Map<String, dynamic>>> cellsWithCoords({int limit = 2000}) async {
    final d = await _openBtsDb();
    return _safeQuery(d, '''
      SELECT key, rat, cid, nci, pci, rsrp, rsrq, sinr, earfcn, nrarfcn,
             lat, lon, last_seen, nr_mode
      FROM bts_cells
      WHERE lat IS NOT NULL AND lon IS NOT NULL
      ORDER BY last_seen DESC
      LIMIT ?
    ''', [limit]);
  }

  Future<Map<String, double>?> coordsByKey(String key) async {
    final d = await _openBtsDb();
    final rows = await _safeQuery(d, '''
      SELECT lat, lon FROM bts_cells
      WHERE key = ? AND lat IS NOT NULL AND lon IS NOT NULL
      ORDER BY last_seen DESC
      LIMIT 1
    ''', [key]);
    if (rows.isEmpty) return null;
    final lat = rows.first['lat'], lon = rows.first['lon'];
    if (lat is num && lon is num) {
      return {'lat': lat.toDouble(), 'lon': lon.toDouble()};
    }
    return null;
  }

  Future<Map<String, dynamic>?> rowByKey(String key) async {
    final d = await _openBtsDb();
    final rows = await _safeQuery(d, '''
      SELECT key, rat, cid, nci, mcc, mnc, tac, pci, earfcn, nrarfcn,
             rsrp, rsrq, sinr, lat, lon, last_seen, nr_mode
      FROM bts_cells
      WHERE key = ?
      LIMIT 1
    ''', [key]);
    if (rows.isEmpty) return null;
    return rows.first;
  }

  Future<List<Map<String, dynamic>>> latestCells({int limit = 500}) async {
    final d = await _openBtsDb();
    return _safeQuery(d, '''
      SELECT key, rat, cid, nci, pci, rsrp, rsrq, sinr, earfcn, nrarfcn,
             lat, lon, last_seen, nr_mode
      FROM bts_cells
      ORDER BY last_seen DESC
      LIMIT ?
    ''', [limit]);
  }

  // ---------- WRITE UPSERT ----------
  Future<void> upsertFromLive(
      Map<String, dynamic> m, {
        double? lat,
        double? lon,
      }) async {
    final d = await _openBtsDb();

    String rat = (m['rat'] as String?)?.toUpperCase() == 'NR' ? 'NR' : 'LTE';
    int? _i(dynamic x) =>
        x == null ? null : (x is num ? x.toInt() : int.tryParse('$x'));
    double? _d(dynamic x) =>
        x == null ? null : (x is num ? x.toDouble() : double.tryParse('$x'));
    String? _s(dynamic x) {
      if (x == null) return null;
      final s = x.toString().trim();
      if (s.isEmpty) return null;
      final u = s.toUpperCase();
      return (u == 'NSA' || u == 'SA') ? u : null;
    }

    final cid = _i(m['cid']);
    final nci = _i(m['nci']);
    final String? key =
    (rat == 'NR' && nci != null) ? 'NR:$nci' : (cid != null ? 'LTE:$cid' : null);
    if (key == null) return;

    final now = _i(m['timestamp']) ?? DateTime.now().millisecondsSinceEpoch;
    final nrMode = (rat == 'NR') ? _s(m['nr_mode']) : null;

    final valuesForId = <String, Object?>{
      'key': key,
      'rat': rat,
      'cid': cid,
      'nci': nci,
      'mcc': _i(m['mcc']),
      'mnc': _i(m['mnc']),
      'tac': _i(m['tac']),
      'pci': _i(m['pci']),
      'earfcn': _i(m['earfcn']),
      'nrarfcn': _i(m['nrarfcn']),
      'nr_mode': nrMode,
    };

    final valuesForKpi = <String, Object?>{
      'rat': rat,
      'mcc': _i(m['mcc']),
      'mnc': _i(m['mnc']),
      'tac': _i(m['tac']),
      'pci': _i(m['pci']),
      'earfcn': _i(m['earfcn']),
      'nrarfcn': _i(m['nrarfcn']),
      'rsrp': _d(m['rsrp']),
      'rsrq': _d(m['rsrq']),
      'sinr': _d(m['sinr']),
      'last_seen': now,
      'nr_mode': nrMode,
    };

    await _safeWrite(d, () async {
      await d.insert(
        'bts_cells',
        valuesForId,
        conflictAlgorithm: ConflictAlgorithm.ignore,
      );
      await d.update(
        'bts_cells',
        valuesForKpi,
        where: 'key = ?',
        whereArgs: [key],
      );
      if (lat != null && lon != null) {
        await d.update(
          'bts_cells',
          {'lat': lat, 'lon': lon},
          where: 'key = ?',
          whereArgs: [key],
        );
      }
    });
  }

  Future<void> clearAllData() async {/* no-op */}

  // ---------- Safe wrappers ----------
  Future<List<Map<String, Object?>>> _safeQuery(
      Database db,
      String sql, [
        List<Object?>? args,
      ]) async {
    try {
      return await db.rawQuery(sql, args);
    } catch (_) {
      _btsDb = null;
      final reopened = await _openBtsDb();
      return await reopened.rawQuery(sql, args);
    }
  }

  Future<void> _safeWrite(Database db, Future<void> Function() action) async {
    try {
      await action();
    } catch (_) {
      _btsDb = null;
      final reopened = await _openBtsDb();
      await action.call();
    }
  }
}
