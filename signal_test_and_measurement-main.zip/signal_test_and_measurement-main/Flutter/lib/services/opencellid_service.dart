import 'dart:convert';
import 'package:http/http.dart' as http;

class OpenCellIDService {
  static const String _url = "https://us1.unwiredlabs.com/v2/process.php";
  static const String _apiKey = "pk.32b2b14e36473bc8b4f1ba95e443fcbd";

  static Future<Map<String, dynamic>?> getCoordinates({
    required int mcc,
    required int mnc,
    required int lac,
    required int cid,
  }) async {
    final body = jsonEncode({
      "token": _apiKey,
      "radio": "lte",
      "mcc": mcc,
      "mnc": mnc,
      "cells": [
        {"lac": lac, "cid": cid}
      ],
      "address": 1
    });

    print("📤 Anfrage an OpenCellID API:");
    print(body);

    try {
      final response = await http.post(
        Uri.parse(_url),
        headers: {"Content-Type": "application/json"},
        body: body,
      );

      print("📥 Antwort-Status: ${response.statusCode}");
      print("📥 Antwort-Body: ${response.body}");

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data["status"] == "ok") {
          return {
            "lat": data["lat"],
            "lon": data["lon"],
            "address": data["address"],
          };
        } else {
          print("⚠️ OpenCellID-Fehler: ${data["message"]}");
        }
      } else {
        print("❌ HTTP-Fehler bei OpenCellID: ${response.statusCode}");
      }
    } catch (e) {
      print("❌ Fehler bei API-Anfrage: $e");
    }

    return null;
  }
}
