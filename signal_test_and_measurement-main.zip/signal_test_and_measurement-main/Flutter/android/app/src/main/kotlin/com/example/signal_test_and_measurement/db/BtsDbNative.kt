package com.example.signal_test_and_measurement.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class BtsDbNative(context: Context) {
    // Use applicationContext to avoid leaking an Activity/Service context.
    private val helper = BtsOpenHelper(context.applicationContext)

    /**
     * Build a stable primary key for a cell row.
     *
     * Policy:
     * - NR + NSA  => canonical "anchor" key (deduplicate LTE vs NSA at same site):
     *      NRNSA:<mcc>-<mnc>-<tac>:<lteCid>
     * - NR + SA   => prefer PLMN+NCI, else NCI-only
     * - LTE       => prefer PLMN+TAC+CID; fallback CID-only
     */
    private fun buildKey(
        rat: String,
        cid: Int?, nci: Long?,
        mcc: Int?, mnc: Int?, tac: Int?,
        pci: Int? = null, nrarfcn: Int? = null,
        nrMode: String? = null
    ): String? {
        val r = rat.uppercase()
        return when (r) {
            "NR" -> {
                val mode = nrMode?.uppercase()
                if (mode == "NSA") {
                    // Canonical NSA anchor key – always the same regardless of NR IDs presence.
                    if (mcc != null && mnc != null && tac != null && cid != null) {
                        return "NRNSA:${mcc}-${mnc}-${tac}:${cid}"
                    }
                    // Without anchor identity we cannot build a deduped NSA key.
                    return null
                } else {
                    // SA: use NCI if possible
                    if (mcc != null && mnc != null && nci != null) return "NRSA:$mcc-$mnc:$nci"
                    if (nci != null) return "NRSA:$nci"
                    // Final fallbacks (rarely hit for SA): try NR IDs
                    val hasPci = (pci != null); val hasArfcn = (nrarfcn != null)
                    if (hasPci && hasArfcn) return "NRSA:${pci}@${nrarfcn}"
                    if (hasPci) return "NRSA:${pci}"
                    return null
                }
            }
            else -> {
                // LTE
                if (mcc != null && mnc != null && tac != null && cid != null) "LTE:$mcc-$mnc-$tac:$cid"
                else cid?.let { "LTE:$it" }
            }
        }
    }

    fun upsertServing(
        rat: String,
        cid: Int?, nci: Long?,
        mcc: Int?, mnc: Int?, tac: Int?,
        pci: Int?, earfcn: Int?, nrarfcn: Int?,
        rsrp: Double?, rsrq: Double?, sinr: Double?,
        lat: Double?, lon: Double?,
        timestamp: Long,
        nrMode: String? = null
    ) {
        val db = helper.writableDatabase
        val key = buildKey(rat, cid, nci, mcc, mnc, tac, pci, nrarfcn, nrMode) ?: return

        db.beginTransaction()
        try {
            // INSERT (ignored if exists)
            val ins = ContentValues().apply {
                put("key", key); put("rat", rat.uppercase())
                putNullOr("cid", cid); putNullOr("nci", nci)
                putNullOr("mcc", mcc); putNullOr("mnc", mnc); putNullOr("tac", tac)
                putNullOr("pci", pci); putNullOr("earfcn", earfcn); putNullOr("nrarfcn", nrarfcn)
                putNullOr("rsrp", rsrp); putNullOr("rsrq", rsrq); putNullOr("sinr", sinr)
                putNullOr("nr_mode", nrMode)
                put("last_seen", timestamp)
            }
            db.insertWithOnConflict("bts_cells", null, ins, SQLiteDatabase.CONFLICT_IGNORE)

            // UPDATE: do NOT overwrite KPIs with nulls; only set what is present.
            val upd = ContentValues().apply {
                put("rat", rat.uppercase())
                putNullOr("mcc", mcc); putNullOr("mnc", mnc); putNullOr("tac", tac)
                putNullOr("pci", pci)
                if (earfcn != null) put("earfcn", earfcn)        // keep LTE EARFCN as fallback for NSA if provided
                if (nrarfcn != null) put("nrarfcn", nrarfcn)
                if (rsrp != null) put("rsrp", rsrp)
                if (rsrq != null) put("rsrq", rsrq)
                if (sinr != null) put("sinr", sinr)
                putNullOr("nr_mode", nrMode)
                put("last_seen", timestamp)
            }
            db.update("bts_cells", upd, "key=?", arrayOf(key))

            // Coordinates only if present (do not clobber with NULL)
            if (lat != null && lon != null) {
                val coords = ContentValues().apply { put("lat", lat); put("lon", lon) }
                db.update("bts_cells", coords, "key=?", arrayOf(key))
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun cellsWithCoords(limit: Int = 1000): List<Map<String, Any?>> {
        val db = helper.readableDatabase
        val out = mutableListOf<Map<String, Any?>>()
        val c = db.query(
            "bts_cells",
            arrayOf("key","rat","cid","nci","mcc","mnc","tac","pci","earfcn","nrarfcn","rsrp","rsrq","sinr","lat","lon","last_seen","nr_mode"),
            "lat IS NOT NULL AND lon IS NOT NULL",
            null, null, null, "last_seen DESC", limit.toString()
        )
        c.use {
            while (it.moveToNext()) {
                out += mapOf(
                    "key" to it.getString(it.getColumnIndexOrThrow("key")),
                    "rat" to it.getString(it.getColumnIndexOrThrow("rat")),
                    "cid" to it.getNullableInt("cid"),
                    "nci" to it.getNullableLong("nci"),
                    "mcc" to it.getNullableInt("mcc"),
                    "mnc" to it.getNullableInt("mnc"),
                    "tac" to it.getNullableInt("tac"),
                    "pci" to it.getNullableInt("pci"),
                    "earfcn" to it.getNullableInt("earfcn"),
                    "nrarfcn" to it.getNullableInt("nrarfcn"),
                    "rsrp" to it.getNullableDouble("rsrp"),
                    "rsrq" to it.getNullableDouble("rsrq"),
                    "sinr" to it.getNullableDouble("sinr"),
                    "lat" to it.getNullableDouble("lat"),
                    "lon" to it.getNullableDouble("lon"),
                    "last_seen" to it.getNullableLong("last_seen"),
                    "nr_mode" to it.getString(it.getColumnIndexOrThrow("nr_mode"))
                )
            }
        }
        return out
    }

    fun latestCells(limit: Int = 500): List<Map<String, Any?>> {
        val db = helper.readableDatabase
        val out = mutableListOf<Map<String, Any?>>()
        val c = db.query(
            "bts_cells",
            arrayOf("key","rat","cid","nci","mcc","mnc","tac","pci","earfcn","nrarfcn","rsrp","rsrq","sinr","lat","lon","last_seen","nr_mode"),
            null, null, null, null, "last_seen DESC", limit.toString()
        )
        c.use {
            while (it.moveToNext()) {
                out += mapOf(
                    "key" to it.getString(it.getColumnIndexOrThrow("key")),
                    "rat" to it.getString(it.getColumnIndexOrThrow("rat")),
                    "cid" to it.getNullableInt("cid"),
                    "nci" to it.getNullableLong("nci"),
                    "mcc" to it.getNullableInt("mcc"),
                    "mnc" to it.getNullableInt("mnc"),
                    "tac" to it.getNullableInt("tac"),
                    "pci" to it.getNullableInt("pci"),
                    "earfcn" to it.getNullableInt("earfcn"),
                    "nrarfcn" to it.getNullableInt("nrarfcn"),
                    "rsrp" to it.getNullableDouble("rsrp"),
                    "rsrq" to it.getNullableDouble("rsrq"),
                    "sinr" to it.getNullableDouble("sinr"),
                    "lat" to it.getNullableDouble("lat"),
                    "lon" to it.getNullableDouble("lon"),
                    "last_seen" to it.getNullableLong("last_seen"),
                    "nr_mode" to it.getString(it.getColumnIndexOrThrow("nr_mode"))
                )
            }
        }
        return out
    }

    fun rowByKey(key: String): Map<String, Any?>? {
        val db = helper.readableDatabase
        val c = db.query(
            "bts_cells",
            arrayOf("key","rat","cid","nci","mcc","mnc","tac","pci","earfcn","nrarfcn","rsrp","rsrq","sinr","lat","lon","last_seen","nr_mode"),
            "key=?", arrayOf(key), null, null, null, "1"
        )
        c.use {
            if (it.moveToFirst()) {
                return mapOf(
                    "key" to it.getString(it.getColumnIndexOrThrow("key")),
                    "rat" to it.getString(it.getColumnIndexOrThrow("rat")),
                    "cid" to it.getNullableInt("cid"),
                    "nci" to it.getNullableLong("nci"),
                    "mcc" to it.getNullableInt("mcc"),
                    "mnc" to it.getNullableInt("mnc"),
                    "tac" to it.getNullableInt("tac"),
                    "pci" to it.getNullableInt("pci"),
                    "earfcn" to it.getNullableInt("earfcn"),
                    "nrarfcn" to it.getNullableInt("nrarfcn"),
                    "rsrp" to it.getNullableDouble("rsrp"),
                    "rsrq" to it.getNullableDouble("rsrq"),
                    "sinr" to it.getNullableDouble("sinr"),
                    "lat" to it.getNullableDouble("lat"),
                    "lon" to it.getNullableDouble("lon"),
                    "last_seen" to it.getNullableLong("last_seen"),
                    "nr_mode" to it.getString(it.getColumnIndexOrThrow("nr_mode"))
                )
            }
        }
        return null
    }

    fun coordsByKey(key: String): Map<String, Double>? {
        val db = helper.readableDatabase
        val c = db.query(
            "bts_cells", arrayOf("lat","lon"),
            "key=? AND lat IS NOT NULL AND lon IS NOT NULL",
            arrayOf(key), null, null, null, "1"
        )
        c.use {
            if (it.moveToFirst()) {
                val lat = it.getNullableDouble("lat")
                val lon = it.getNullableDouble("lon")
                if (lat != null && lon != null) return mapOf("lat" to lat, "lon" to lon)
            }
        }
        return null
    }

    // ContentValues helpers
    private fun ContentValues.putNullOr(col: String, v: Int?) { if (v == null) putNull(col) else put(col, v) }
    private fun ContentValues.putNullOr(col: String, v: Long?) { if (v == null) putNull(col) else put(col, v) }
    private fun ContentValues.putNullOr(col: String, v: Double?) { if (v == null) putNull(col) else put(col, v) }
    private fun ContentValues.putNullOr(col: String, v: String?) { if (v == null) putNull(col) else put(col, v) }

    private class BtsOpenHelper(ctx: Context) :
        SQLiteOpenHelper(ctx, "bts_v1.db", null, DB_VERSION) {

        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE IF NOT EXISTS bts_cells(
                    key TEXT PRIMARY KEY,
                    rat TEXT NOT NULL,
                    cid INTEGER NULL,
                    nci INTEGER NULL,
                    mcc INTEGER NULL,
                    mnc INTEGER NULL,
                    tac INTEGER NULL,
                    pci INTEGER NULL,
                    earfcn INTEGER NULL,
                    nrarfcn INTEGER NULL,
                    rsrp REAL NULL,
                    rsrq REAL NULL,
                    sinr REAL NULL,
                    lat REAL NULL,
                    lon REAL NULL,
                    last_seen INTEGER NULL,
                    nr_mode TEXT NULL
                );
            """.trimIndent())
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_bts_last   ON bts_cells(last_seen DESC);")
            db.execSQL("CREATE INDEX IF NOT EXISTS idx_bts_coords ON bts_cells(lat,lon);")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            if (oldVersion < 2) {
                try { db.execSQL("ALTER TABLE bts_cells ADD COLUMN lat REAL") } catch (_: Exception) {}
                try { db.execSQL("ALTER TABLE bts_cells ADD COLUMN lon REAL") } catch (_: Exception) {}
            }
            if (oldVersion < 3) {
                try { db.execSQL("CREATE INDEX IF NOT EXISTS idx_bts_coords ON bts_cells(lat,lon);") } catch (_: Exception) {}
            }
            if (oldVersion < 4) {
                try { db.execSQL("ALTER TABLE bts_cells ADD COLUMN nr_mode TEXT") } catch (_: Exception) {}
            }
        }

        override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { /* no-op */ }

        companion object { private const val DB_VERSION = 4 }
    }

    // Cursor helpers
    private fun android.database.Cursor.getNullableInt(col: String): Int? {
        val i = getColumnIndexOrThrow(col); return if (isNull(i)) null else getInt(i)
    }
    private fun android.database.Cursor.getNullableLong(col: String): Long? {
        val i = getColumnIndexOrThrow(col); return if (isNull(i)) null else getLong(i)
    }
    private fun android.database.Cursor.getNullableDouble(col: String): Double? {
        val i = getColumnIndexOrThrow(col); return if (isNull(i)) null else getDouble(i)
    }
}
