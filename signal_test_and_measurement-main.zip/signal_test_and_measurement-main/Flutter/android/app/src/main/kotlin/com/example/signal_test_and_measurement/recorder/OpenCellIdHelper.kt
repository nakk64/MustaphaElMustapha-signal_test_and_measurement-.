package com.example.signal_test_and_measurement.recorder

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder


object OpenCellIdHelper {
    private const val TAG = "OpenCellIdHelper"
    private const val PREFS = "ocid_prefs"
    private const val PREF_KEY = "ocid_key"

    data class Coords(val lat: Double, val lon: Double)

    // --- API key handling from SharedPreferences / Manifest ---
    fun setApiKey(ctx: Context, key: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(PREF_KEY, key.trim()).apply()
    }
    private fun resolveApiKey(ctx: Context): String? {
        val fromPrefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(PREF_KEY, null)?.trim()
        if (!fromPrefs.isNullOrEmpty()) return fromPrefs
        return try {
            val ai = ctx.packageManager.getApplicationInfo(ctx.packageName, PackageManager.GET_META_DATA)
            ai.metaData?.getString("OPENCELLID_API_KEY")?.trim()
        } catch (_: Exception) { null }
    }

    private fun okInt(v: Int?) = v != null && v != Int.MAX_VALUE && v > 0
    private fun okLong(v: Long?) = v != null && v != Long.MAX_VALUE && v > 0L

    // ---------------- LTE ----------------
    fun lookupLte(ctx: Context, mcc: Int?, mnc: Int?, tac: Int?, cid: Int?): Coords? {
        if (!okInt(mcc) || !okInt(mnc) || !okInt(tac) || !okInt(cid)) {
            Log.d(TAG, "LTE skip: mcc=$mcc mnc=$mnc tac=$tac cid=$cid")
            return null
        }
        val key = resolveApiKey(ctx) ?: run {
            Log.w(TAG, "No OCID key set"); return null
        }

        val url = "https://opencellid.org/cell/get" +
                "?key=${URLEncoder.encode(key, "UTF-8")}" +
                "&mcc=$mcc&mnc=$mnc&lac=$tac&cellid=$cid&radio=LTE&format=json"

        return fetchCoords(url)
    }

    // ---------------- NR ----------------
    fun lookupNr(ctx: Context, mcc: Int?, mnc: Int?, tac: Int?, nci: Long?): Coords? {
        if (!okInt(mcc) || !okInt(mnc) || !okInt(tac) || !okLong(nci)) {
            Log.d(TAG, "NR skip: mcc=$mcc mnc=$mnc tac=$tac nci=$nci")
            return null
        }
        val key = resolveApiKey(ctx) ?: run {
            Log.w(TAG, "No OCID key set"); return null
        }

        val url = "https://opencellid.org/cell/get" +
                "?key=${URLEncoder.encode(key, "UTF-8")}" +
                "&mcc=$mcc&mnc=$mnc&lac=$tac&cellid=$nci&radio=NR&format=json"

        return fetchCoords(url)
    }

    // ----------- HTTP fetch + parsing (JSON or XML) -----------
    private fun fetchCoords(urlStr: String): Coords? {
        val (code, body) = httpGet(urlStr) ?: return null
        if (code == 401 || code == 403) {
            Log.w(TAG, "OCID auth error $code: ${body.take(120)}")
            return null
        }
        if (body.isEmpty()) return null

        // JSON response
        if (body.first() == '{' || body.first() == '[') {
            return try {
                val json = JSONObject(body)
                val latLon = if (json.has("lat") && json.has("lon")) {
                    Pair(json.optDouble("lat", Double.NaN), json.optDouble("lon", Double.NaN))
                } else {
                    val cells = json.optJSONArray("cells")
                    if (cells != null && cells.length() > 0) {
                        val c0 = cells.getJSONObject(0)
                        Pair(c0.optDouble("lat", Double.NaN), c0.optDouble("lon", Double.NaN))
                    } else null
                }
                latLon?.let { (lat, lon) ->
                    if (!lat.isNaN() && !lon.isNaN()) Coords(lat, lon) else null
                }
            } catch (e: Exception) {
                Log.w(TAG, "JSON parse failed: ${e.message}")
                null
            }
        }

        // XML response (simple regex-based parsing)
        if (body.startsWith("<")) {
            val fail = Regex("""<err[^>]*code="(\d+)"[^>]*>""").find(body)
            if (fail != null) {
                Log.w(TAG, "OCID returned err code=${fail.groupValues[1]} body=${body.take(120)}")
                return null
            }
            val lat = Regex("""lat="([\-0-9.]+)"""").find(body)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            val lon = Regex("""lon="([\-0-9.]+)"""").find(body)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            if (lat != null && lon != null) return Coords(lat, lon)
            Log.w(TAG, "XML without lat/lon: ${body.take(120)}")
            return null
        }

        Log.w(TAG, "Unknown response: ${body.take(80)}")
        return null
    }

    /** Simple blocking HTTP GET */
    private fun httpGet(urlStr: String): Pair<Int, String>? {
        return try {
            val c = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 8000
                readTimeout = 8000
                // Do not enforce JSON; server often returns XML
                setRequestProperty("User-Agent", "SignalApp/1.0 (Android)")
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
            val body = BufferedReader(InputStreamReader(stream)).use { it.readText() }.trim()
            Pair(code, body)
        } catch (e: Exception) {
            Log.w(TAG, "HTTP GET failed: ${e.message}")
            null
        }
    }
}
