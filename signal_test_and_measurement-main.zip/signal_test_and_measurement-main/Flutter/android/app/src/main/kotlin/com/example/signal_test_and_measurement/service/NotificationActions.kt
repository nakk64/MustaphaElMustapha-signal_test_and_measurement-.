package com.example.signal_test_and_measurement.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class NotificationActions : BroadcastReceiver() {
    companion object { const val ACTION_STOP = "com.example.signal_test_and_measurement.action.STOP" }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_STOP) {
            context.stopService(Intent(context, BtsForegroundService::class.java))
        }
    }
}
