package com.example.signal_test_and_measurement.recorder

import android.content.Context
import android.os.Build
import android.telephony.*
import com.example.signal_test_and_measurement.db.BtsDbNative
import kotlinx.coroutines.*

class BtsRecorder(private val ctx: Context) {

    private val tm: TelephonyManager =
        ctx.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager

    private val db = BtsDbNative(ctx)
    private var started = false

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    // Tracks NSA based on TelephonyDisplayInfo (some devices do NOT expose CellInfoNr in NSA)
    @Volatile private var isNsaActive: Boolean = false

    /** Start recording cell info */
    fun start() {
        if (started) return
        started = true

        if (Build.VERSION.SDK_INT >= 31) {
            // Modern callbacks
            tm.registerTelephonyCallback(ctx.mainExecutor, telephonyCb31)
        } else {
            // Legacy CellInfo callback
            @Suppress("DEPRECATION")
            tm.listen(phoneStateListener, PhoneStateListener.LISTEN_CELL_INFO)
        }

        // DisplayInfo (NSA) callback for API >= 30
        if (Build.VERSION.SDK_INT >= 30) {
            tm.registerTelephonyCallback(ctx.mainExecutor, displayInfoCb30)
        }

        // First snapshot
        takeOneSnapshot()
    }

    /** Stop recording cell info */
    fun stop() {
        if (!started) return
        started = false

        if (Build.VERSION.SDK_INT >= 31) {
            tm.unregisterTelephonyCallback(telephonyCb31)
        } else {
            @Suppress("DEPRECATION")
            tm.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE)
        }
        if (Build.VERSION.SDK_INT >= 30) {
            tm.unregisterTelephonyCallback(displayInfoCb30)
        }

        scope.coroutineContext.cancelChildren()
    }

    // ----- API 31+: CellInfo callback -----
    private val telephonyCb31 = object : TelephonyCallback(),
        TelephonyCallback.CellInfoListener {
        override fun onCellInfoChanged(cellInfo: MutableList<CellInfo>) {
            persistFromList(cellInfo)
        }
    }

    // ----- API 30+: DisplayInfo (detect NSA reliably) -----
    private val displayInfoCb30 = object : TelephonyCallback(),
        TelephonyCallback.DisplayInfoListener {
        override fun onDisplayInfoChanged(displayInfo: TelephonyDisplayInfo) {
            // Consider NSA when overrideNetworkType reports NR_NSA (value or constant depending on API level)
            isNsaActive = when {
                // Constant is public since API 30
                displayInfo.overrideNetworkType == TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA -> true
                else -> false
            }
        }
    }

    // ----- Legacy <31: CellInfo callback -----
    private val phoneStateListener = object : PhoneStateListener() {
        @Suppress("DEPRECATION")
        override fun onCellInfoChanged(cellInfo: List<CellInfo>?) {
            if (cellInfo != null) persistFromList(cellInfo)
        }
    }

    /** Manually fetch one snapshot of all cells */
    private fun takeOneSnapshot() {
        try {
            val list = tm.allCellInfo
            if (list != null) persistFromList(list)
        } catch (_: SecurityException) { /* ignore */ }
    }

    /**
     * Persist policy :
     * - If LTE is registered AND (any NR cell exists OR NSA is active by DisplayInfo):
     *      -> write ONLY one row marked as NR with nrMode="NSA"
     *      -> BUT keep ALL KPIs/Frequency/PCI/Coordinates from LTE (so it looks identical to LTE)
     *      -> no separate LTE row is written.
     * - Else (non-NSA):
     *      -> persist LTE registered (green) as before.
     *      -> persist registered NR as SA (dark blue) with real NR KPIs.
     */
    private fun persistFromList(list: List<CellInfo>) {
        val now = System.currentTimeMillis()

        val lteServing = list.firstOrNull { it.isRegistered && it is CellInfoLte } as? CellInfoLte
        val anyNrPresent = list.any { it is CellInfoNr }

        // Use DisplayInfo to detect NSA even if CellInfoNr is NOT present
        val nsaDetected = (lteServing != null) && (anyNrPresent || isNsaActive)

        if (nsaDetected) {
            // ---------- NSA PATH: single row shown as "5G NSA", but with LTE KPIs/Freq/PCI/Coords ----------
            val lid = lteServing!!.cellIdentity
            val lss = lteServing.cellSignalStrength

            val lteCid    = safeInt(lid.ci)
            val lteMcc    = safeInt(lid.mccString?.toIntOrNull() ?: lid.mcc)
            val lteMnc    = safeInt(lid.mncString?.toIntOrNull() ?: lid.mnc)
            val lteTac    = safeInt(lid.tac)
            val ltePci    = safeInt(lid.pci)
            val lteEarfcn = safeInt(lid.earfcn)

            scope.launch(Dispatchers.IO) {
                // LTE coordinates (exactly the same as LTE path)
                val coords = try {
                    OpenCellIdHelper.lookupLte(
                        ctx = ctx,
                        mcc = lteMcc,
                        mnc = lteMnc,
                        tac = lteTac,
                        cid = lteCid
                    )
                } catch (_: Throwable) { null }

                // KPIs from LTE (keep Live parity)
                val rsrp = safeDouble(lss.rsrp?.toDouble())
                val rsrq = safeDouble(lss.rsrq?.toDouble())
                val sinr = null // LTE SINR typically not available; keep null as before

                // Upsert only one NSA row:
                // - rat="NR" + nrMode="NSA" -> UI shows "5G NSA" and light-blue recorded markers
                // - Anchor IDs via LTE (mcc/mnc/tac/cid) so native can build NRNSA:<mcc>-<mnc>-<tac>:<cid>
                // - KPIs/Freq/PCI/Coords -> ALL from LTE to match Live values exactly
                db.upsertServing(
                    rat       = "NR",
                    cid       = lteCid,         // anchor (used by NRNSA key in native)
                    nci       = null,           // not needed for NSA anchor
                    mcc       = lteMcc,
                    mnc       = lteMnc,
                    tac       = lteTac,
                    pci       = ltePci,         // keep LTE PCI
                    earfcn    = lteEarfcn,      // keep LTE EARFCN
                    nrarfcn   = null,           // do not use NR ARFCN in NSA
                    rsrp      = rsrp,
                    rsrq      = rsrq,
                    sinr      = sinr,
                    lat       = coords?.lat,
                    lon       = coords?.lon,
                    timestamp = now,
                    nrMode    = "NSA"
                )
            }
            return
        }

        // ---------- NON-NSA PATH ----------
        list.filter { it.isRegistered }.forEach { ci ->
            when (ci) {
                is CellInfoLte -> {
                    val id = ci.cellIdentity
                    val ss = ci.cellSignalStrength
                    scope.launch(Dispatchers.IO) {
                        val coords = OpenCellIdHelper.lookupLte(
                            ctx = ctx,
                            mcc = id.mccString?.toIntOrNull() ?: id.mcc,
                            mnc = id.mncString?.toIntOrNull() ?: id.mnc,
                            tac = id.tac,
                            cid = id.ci
                        )
                        db.upsertServing(
                            rat       = "LTE",
                            cid       = safeInt(id.ci),
                            nci       = null,
                            mcc       = safeInt(id.mccString?.toIntOrNull() ?: id.mcc),
                            mnc       = safeInt(id.mncString?.toIntOrNull() ?: id.mnc),
                            tac       = safeInt(id.tac),
                            pci       = safeInt(id.pci),
                            earfcn    = safeInt(id.earfcn),
                            nrarfcn   = null,
                            rsrp      = safeDouble(ss.rsrp?.toDouble()),
                            rsrq      = safeDouble(ss.rsrq?.toDouble()),
                            sinr      = null,
                            lat       = coords?.lat,
                            lon       = coords?.lon,
                            timestamp = System.currentTimeMillis(),
                            nrMode    = null
                        )
                    }
                }
                is CellInfoNr -> {
                    // Registered NR => SA (Standalone) with real NR KPIs
                    val id = ci.cellIdentity as CellIdentityNr
                    val ss = ci.cellSignalStrength as CellSignalStrengthNr
                    scope.launch(Dispatchers.IO) {
                        val coords = OpenCellIdHelper.lookupNr(
                            ctx = ctx,
                            mcc = id.mccString?.toIntOrNull(),
                            mnc = id.mncString?.toIntOrNull(),
                            tac = id.tac,
                            nci = id.nci
                        )
                        db.upsertServing(
                            rat       = "NR",
                            cid       = null,
                            nci       = safeLong(id.nci),
                            mcc       = safeInt(id.mccString?.toIntOrNull()),
                            mnc       = safeInt(id.mncString?.toIntOrNull()),
                            tac       = safeInt(id.tac),
                            pci       = safeInt(id.pci),
                            earfcn    = null,
                            nrarfcn   = safeInt(id.nrarfcn),
                            rsrp      = safeDouble(pickValid(ss.ssRsrp, ss.csiRsrp)?.toDouble()),
                            rsrq      = safeDouble(pickValid(ss.ssRsrq, ss.csiRsrq)?.toDouble()),
                            sinr      = safeDouble(pickValid(ss.ssSinr, ss.csiSinr)?.toDouble()),
                            lat       = coords?.lat,
                            lon       = coords?.lon,
                            timestamp = System.currentTimeMillis(),
                            nrMode    = "SA"
                        )
                    }
                }
            }
        }
    }

    /** Pick the first valid measurement */
    private fun pickValid(primary: Int, secondary: Int): Int? =
        when {
            primary != Int.MAX_VALUE -> primary
            secondary != Int.MAX_VALUE -> secondary
            else -> null
        }

    /** Safety wrappers to convert invalid values into nulls */
    private fun safeInt(v: Int?): Int? = if (v == null || v == Int.MAX_VALUE) null else v
    private fun safeLong(v: Long?): Long? = if (v == null || v == Long.MAX_VALUE) null else v
    private fun safeDouble(v: Double?): Double? =
        if (v == null || v.isNaN() || v.isInfinite()) null else v
}
