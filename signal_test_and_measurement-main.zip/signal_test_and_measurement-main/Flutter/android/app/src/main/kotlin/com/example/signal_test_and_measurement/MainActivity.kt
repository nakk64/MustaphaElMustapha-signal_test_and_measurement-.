// android/app/src/main/kotlin/com/example/signal_test_and_measurement/MainActivity.kt
//
// Streams REAL modem data via EventChannel("bts/info").
// Controls the foreground recorder via MethodChannel("bts/db_service").
// Self-test for OpenCellID via MethodChannel("ocid/test").
// EXPOSES DB read APIs for Flutter Map via MethodChannel("bts/db_details").

package com.example.signal_test_and_measurement

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.*
import androidx.core.content.ContextCompat
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodChannel
import org.json.JSONObject
import kotlin.concurrent.fixedRateTimer
import kotlin.math.max
import kotlin.math.min

// Service + helpers
import com.example.signal_test_and_measurement.service.BtsForegroundService
import com.example.signal_test_and_measurement.recorder.OpenCellIdHelper
import com.example.signal_test_and_measurement.db.BtsDbNative

class MainActivity : FlutterActivity() {

    // Channel names used by Flutter <-> Android bridge
    private val CHANNEL_BTS_INFO   = "bts/info"
    private val CHANNEL_BG_CTRL    = "bts/db_service"
    private val CHANNEL_OCID_TEST  = "ocid/test"
    private val CHANNEL_DB_DETAILS = "bts/db_details"

    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }
    private var timer: java.util.Timer? = null

    // Telephony state caches for snapshot emission
    private var telephonyManager: TelephonyManager? = null
    private var phoneStateListener: PhoneStateListener? = null
    private var telephonyCallback31: Any? = null

    private var lastDisplayInfo: TelephonyDisplayInfo? = null
    private var lastServiceState: ServiceState? = null
    private var lastSignalStrength: SignalStrength? = null
    private var lastDataNetworkType: Int? = null
    private var lastAllCellInfo: List<CellInfo>? = null

    private var currentSink: EventChannel.EventSink? = null

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)

        telephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager

        // ---- Live KPIs stream ----
        EventChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_BTS_INFO)
            .setStreamHandler(object : EventChannel.StreamHandler {
                override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                    currentSink = events
                    startLive() // begin periodic modem polling & callbacks
                }
                override fun onCancel(arguments: Any?) {
                    currentSink = null
                    stopLive() // stop timers and listeners
                }
            })

        // ---- Foreground recorder control (start/stop Android Service) ----
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_BG_CTRL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "start" -> { startBgService(); result.success(true) }
                    "stop"  -> { stopBgService();  result.success(true) }
                    else -> result.notImplemented()
                }
            }

        // ---- OpenCellID self-test: query current serving cell without ADB ----
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_OCID_TEST)
            .setMethodCallHandler { call, result ->
                if (call.method != "testCurrent") {
                    result.notImplemented(); return@setMethodCallHandler
                }
                val tm = telephonyManager
                if (tm == null) { result.error("tm_null", "TelephonyManager null", null); return@setMethodCallHandler }
                if (!hasAnyRequiredPermission()) {
                    result.error("perm", "Missing phone/location permission", null); return@setMethodCallHandler
                }
                val list: List<CellInfo>? = try {
                    @Suppress("MissingPermission") tm.allCellInfo
                } catch (_: SecurityException) { null }
                if (list == null) { result.error("no_list", "Could not read cell info", null); return@setMethodCallHandler }
                val serving = list.firstOrNull { it.isRegistered }
                if (serving == null) { result.error("no_serving", "No registered cell", null); return@setMethodCallHandler }

                // Basic validators for IDs
                fun okTac(t: Int?) = t != null && t != Int.MAX_VALUE && t > 0
                fun okCid(c: Int?) = c != null && c != Int.MAX_VALUE && c > 0
                fun okNci(n: Long?) = n != null && n != Long.MAX_VALUE && n > 0L

                val out = HashMap<String, Any?>()
                when (serving) {
                    is CellInfoLte -> {
                        val id = serving.cellIdentity
                        val mcc = id.mccString?.toIntOrNull() ?: id.mcc
                        val mnc = id.mncString?.toIntOrNull() ?: id.mnc
                        val tac = id.tac
                        val cid = id.ci
                        out["rat"] = "LTE"; out["mcc"] = mcc; out["mnc"] = mnc; out["tac"] = tac; out["cid"] = cid
                        if (!okTac(tac) || !okCid(cid)) { out["status"] = "invalid_params"; result.success(out); return@setMethodCallHandler }
                        val coords = OpenCellIdHelper.lookupLte(this, mcc, mnc, tac, cid)
                        out["status"] = if (coords == null) "no_coords" else "ok"
                        out["lat"] = coords?.lat; out["lon"] = coords?.lon
                        result.success(out)
                    }
                    is CellInfoNr -> {
                        val id = serving.cellIdentity as CellIdentityNr
                        val mcc = id.mccString?.toIntOrNull()
                        val mnc = id.mncString?.toIntOrNull()
                        val tac = id.tac
                        val nci = id.nci
                        out["rat"] = "NR"; out["mcc"] = mcc; out["mnc"] = mnc; out["tac"] = tac; out["nci"] = nci
                        if (!okTac(tac) || !okNci(nci)) { out["status"] = "invalid_params"; result.success(out); return@setMethodCallHandler }
                        val coords = OpenCellIdHelper.lookupNr(this, mcc, mnc, tac, nci)
                        out["status"] = if (coords == null) "no_coords" else "ok"
                        out["lat"] = coords?.lat; out["lon"] = coords?.lon
                        result.success(out)
                    }
                    else -> result.error("unsupported", "Only LTE/NR supported", null)
                }
            }

        // ---- DB data exposure for Flutter map/details ----
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL_DB_DETAILS)
            .setMethodCallHandler { call, result ->
                val db = BtsDbNative(this)
                when (call.method) {
                    "cellsWithCoords" -> {
                        val limit = call.argument<Int>("limit") ?: 1000
                        result.success(db.cellsWithCoords(limit))
                    }
                    "coordsByKey" -> {
                        val key = call.argument<String>("key")
                        if (key.isNullOrEmpty()) result.error("bad_args","key required",null)
                        else result.success(db.coordsByKey(key))
                    }
                    "latestCells" -> {
                        val limit = call.argument<Int>("limit") ?: 500
                        result.success(db.latestCells(limit))
                    }
                    "rowByKey" -> {
                        val key = call.argument<String>("key")
                        if (key.isNullOrEmpty()) result.error("bad_args","key required",null)
                        else result.success(db.rowByKey(key))
                    }
                    else -> result.notImplemented()
                }
            }
    }

    // ---- Foreground Service control helpers ----
    private fun startBgService() {
        if (!hasAnyRequiredPermission()) return
        val intent = Intent(this, BtsForegroundService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ContextCompat.startForegroundService(this, intent)
        } else {
            startService(intent)
        }
    }
    private fun stopBgService() {
        val intent = Intent(this, BtsForegroundService::class.java)
        stopService(intent)
    }

    // ---- Live modem stream lifecycle ----
    private fun startLive() {
        stopLive() // ensure clean start
        if (!hasAnyRequiredPermission()) {
            // Emit a periodic permission hint until granted
            timer = fixedRateTimer("perm_hint", daemon = true, initialDelay = 0L, period = 1000L) {
                val payload = JSONObject().apply {
                    put("error", "permission_missing")
                    put("hint", "Grant PHONE + LOCATION permissions to read cell info")
                    put("timestamp", System.currentTimeMillis())
                }
                post(currentSink, payload)
            }
            return
        }
        registerTelephonyListeners()
        // Poll/request cell info regularly; also rely on callbacks to push updates
        timer = fixedRateTimer("modem_poll", daemon = true, initialDelay = 0L, period = 1000L) {
            try {
                val tm = telephonyManager ?: return@fixedRateTimer
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    @Suppress("MissingPermission")
                    tm.requestCellInfoUpdate(mainExecutor, object : TelephonyManager.CellInfoCallback() {
                        override fun onCellInfo(cellInfo: MutableList<CellInfo>) {
                            lastAllCellInfo = cellInfo
                            emitSnapshot(cellInfo)
                        }
                    })
                } else {
                    val list = safeAllCellInfo(tm)
                    lastAllCellInfo = list
                    emitSnapshot(list)
                }
            } catch (_: Throwable) { }
        }
    }
    private fun stopLive() {
        timer?.cancel(); timer = null
        unregisterTelephonyListeners()
    }

    // Check minimal phone + location permission set
    private fun hasAnyRequiredPermission(): Boolean {
        val ctx = this
        val locFine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val locCoarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val phone = ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
        val phoneBasicOk =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_BASIC_PHONE_STATE) == PackageManager.PERMISSION_GRANTED
            else true
        return (locFine || locCoarse) && phone && phoneBasicOk
    }

    // Register telephony listeners for both modern and legacy APIs
    private fun registerTelephonyListeners() {
        val tm = telephonyManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val cb = object : TelephonyCallback(),
                TelephonyCallback.DisplayInfoListener,
                TelephonyCallback.ServiceStateListener,
                TelephonyCallback.SignalStrengthsListener,
                TelephonyCallback.DataConnectionStateListener,
                TelephonyCallback.CellInfoListener {
                override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) { lastDisplayInfo = telephonyDisplayInfo }
                override fun onServiceStateChanged(serviceState: ServiceState) { lastServiceState = serviceState }
                override fun onSignalStrengthsChanged(signalStrength: SignalStrength) { lastSignalStrength = signalStrength }
                override fun onDataConnectionStateChanged(state: Int, networkType: Int) { lastDataNetworkType = networkType }
                override fun onCellInfoChanged(cellInfo: MutableList<CellInfo>) {
                    lastAllCellInfo = cellInfo
                    emitSnapshot(cellInfo)
                }
            }
            tm.registerTelephonyCallback(mainExecutor, cb)
            telephonyCallback31 = cb
        } else {
            val listener = object : PhoneStateListener() {
                override fun onDisplayInfoChanged(telephonyDisplayInfo: TelephonyDisplayInfo) { lastDisplayInfo = telephonyDisplayInfo }
                override fun onServiceStateChanged(serviceState: ServiceState?) { lastServiceState = serviceState }
                override fun onSignalStrengthsChanged(signalStrength: SignalStrength?) { lastSignalStrength = signalStrength }
                @Deprecated("Single-arg legacy callback")
                override fun onDataConnectionStateChanged(state: Int) {
                    val tmLocal = telephonyManager
                    lastDataNetworkType = try { @Suppress("MissingPermission") tmLocal?.dataNetworkType } catch (_: SecurityException) { null }
                }
                @Deprecated("Legacy cell info callback")
                override fun onCellInfoChanged(cellInfo: MutableList<CellInfo>?) {
                    lastAllCellInfo = cellInfo
                    emitSnapshot(cellInfo)
                }
            }
            phoneStateListener = listener
            @Suppress("DEPRECATION")
            tm.listen(
                listener,
                PhoneStateListener.LISTEN_DISPLAY_INFO_CHANGED or
                        PhoneStateListener.LISTEN_SERVICE_STATE or
                        PhoneStateListener.LISTEN_SIGNAL_STRENGTHS or
                        PhoneStateListener.LISTEN_DATA_CONNECTION_STATE or
                        PhoneStateListener.LISTEN_CELL_INFO
            )
        }
    }
    private fun unregisterTelephonyListeners() {
        val tm = telephonyManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (telephonyCallback31 as? TelephonyCallback)?.let { tm.unregisterTelephonyCallback(it) }
            telephonyCallback31 = null
        } else {
            phoneStateListener?.let {
                @Suppress("DEPRECATION") tm.listen(it, PhoneStateListener.LISTEN_NONE)
            }
            phoneStateListener = null
        }
    }

    // Build and emit a JSON snapshot to Flutter listeners
    private fun emitSnapshot(list: List<CellInfo>?) {
        val tm = telephonyManager ?: return
        val serving = list?.firstOrNull { it.isRegistered }
        val (rat, nrMode) = resolveRatAndMode(tm, serving, lastDisplayInfo, lastDataNetworkType)

        val json = when (serving) {
            is CellInfoNr  -> buildNrJson(tm, serving, rat, nrMode)
            is CellInfoLte -> buildLteJson(tm, serving, rat, nrMode)
            else -> JSONObject().apply {
                put("rat", rat); if (nrMode != null) put("nrMode", nrMode) else put("nrMode", JSONObject.NULL)
                put("mcc", JSONObject.NULL); put("mnc", JSONObject.NULL)
                put("tac", JSONObject.NULL); put("lac", JSONObject.NULL)
                put("cid", JSONObject.NULL); put("nci", JSONObject.NULL)
                put("pci", JSONObject.NULL); put("earfcn", JSONObject.NULL); put("nrarfcn", JSONObject.NULL)
                put("band", JSONObject.NULL)
                lastSignalStrength?.let { ss ->
                    val (rsrp, rsrq, sinr) = guessKpisFromSignalStrength(ss, rat ?: "LTE")
                    put("rsrp", rsrp?.let { clamp(it, -140.0, -50.0) } ?: JSONObject.NULL)
                    put("rsrq", rsrq?.let { clamp(it, -25.0, -1.0) } ?: JSONObject.NULL)
                    put("sinr", sinr?.let { clamp(it, -10.0, 30.0) } ?: JSONObject.NULL)
                    put("rssi", JSONObject.NULL)
                } ?: run {
                    put("rsrp", JSONObject.NULL); put("rsrq", JSONObject.NULL); put("sinr", JSONObject.NULL); put("rssi", JSONObject.NULL)
                }
                put("timestamp", System.currentTimeMillis())
            }
        }
        post(currentSink, json)
    }

    // Safe snapshot read for legacy devices
    private fun safeAllCellInfo(tm: TelephonyManager): List<CellInfo>? =
        try { @Suppress("MissingPermission") tm.allCellInfo } catch (_: SecurityException) { null }

    // Decide RAT (LTE/NR) and NR mode (NSA/SA) from multiple signals
    private fun resolveRatAndMode(
        tm: TelephonyManager,
        serving: CellInfo?,
        displayInfo: TelephonyDisplayInfo?,
        dataNt: Int?
    ): Pair<String, String?> {
        var rat = when (serving) {
            is CellInfoNr -> "NR"
            is CellInfoLte -> "LTE"
            else -> null
        }
        var mode: String? = null

        val overrideType = displayInfo?.overrideNetworkType
        val isNsa = if (overrideType != null) {
            when (overrideType) {
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA,
                TelephonyDisplayInfo.OVERRIDE_NETWORK_TYPE_NR_NSA_MMWAVE -> true
                else -> false
            }
        } else false

        val dataType = try { @Suppress("MissingPermission") tm.dataNetworkType } catch (_: SecurityException) { dataNt }

        when {
            isNsa -> { rat = "NR"; mode = "NSA" }
            dataType == TelephonyManager.NETWORK_TYPE_NR -> { rat = "NR"; mode = "SA" }
            rat == null -> { rat = "LTE" }
        }
        return rat to mode
    }

    // Build LTE JSON payload with clamped KPIs
    private fun buildLteJson(tm: TelephonyManager, ci: CellInfoLte, rat: String, nrMode: String?): JSONObject {
        val id = ci.cellIdentity
        val ss = ci.cellSignalStrength

        val mcc = id.mccString?.toIntOrNull()
        val mnc = id.mncString?.toIntOrNull()
        val tac = id.tac.takeIf { it != Int.MAX_VALUE }
        val pci = id.pci.takeIf { it != Int.MAX_VALUE }
        val earfcn = id.earfcn.takeIf { it != Int.MAX_VALUE }
        val cid = id.ci.takeIf { it != Int.MAX_VALUE }

        val rsrp = ss.rsrp.takeIf { it != Int.MAX_VALUE }?.toDouble()
        val rsrq = ss.rsrq.takeIf { it != Int.MAX_VALUE }?.toDouble()
        val sinr = ss.rssnr.takeIf { it != Int.MAX_VALUE }?.toDouble()

        return JSONObject().apply {
            put("rat", rat); if (nrMode != null) put("nrMode", nrMode) else put("nrMode", JSONObject.NULL)
            put("mcc", mcc ?: JSONObject.NULL); put("mnc", mnc ?: JSONObject.NULL)
            put("tac", tac ?: JSONObject.NULL); put("lac", JSONObject.NULL)
            put("cid", cid ?: JSONObject.NULL); put("nci", JSONObject.NULL)
            put("pci", pci ?: JSONObject.NULL); put("earfcn", earfcn ?: JSONObject.NULL); put("nrarfcn", JSONObject.NULL)
            put("band", JSONObject.NULL)
            put("rsrp", rsrp?.let { clamp(it, -140.0, -50.0) } ?: JSONObject.NULL)
            put("rsrq", rsrq?.let { clamp(it, -25.0, -1.0) } ?: JSONObject.NULL)
            put("sinr", sinr?.let { clamp(it, -10.0, 30.0) } ?: JSONObject.NULL)
            put("rssi", JSONObject.NULL)
            put("timestamp", System.currentTimeMillis())
        }
    }

    // Build NR JSON payload with clamped KPIs (prefers SS; falls back to CSI)
    private fun buildNrJson(tm: TelephonyManager, ci: CellInfoNr, rat: String, nrMode: String?): JSONObject {
        val id = ci.cellIdentity as CellIdentityNr
        val ss = ci.cellSignalStrength as CellSignalStrengthNr

        val mcc = id.mccString?.toIntOrNull()
        val mnc = id.mncString?.toIntOrNull()
        val tac = id.tac.takeIf { it != Int.MAX_VALUE }
        val pci = id.pci.takeIf { it != Int.MAX_VALUE }
        val nrarfcn = id.nrarfcn.takeIf { it != Int.MAX_VALUE }
        val nci = id.nci.takeIf { it != Long.MAX_VALUE }

        val rsrp = pickValid(ss.ssRsrp, ss.csiRsrp)?.toDouble()
        val rsrq = pickValid(ss.ssRsrq, ss.csiRsrq)?.toDouble()
        val sinr = pickValid(ss.ssSinr, ss.csiSinr)?.toDouble()

        return JSONObject().apply {
            put("rat", rat); if (nrMode != null) put("nrMode", nrMode) else put("nrMode", JSONObject.NULL)
            put("mcc", mcc ?: JSONObject.NULL); put("mnc", mnc ?: JSONObject.NULL)
            put("tac", tac ?: JSONObject.NULL); put("lac", JSONObject.NULL)
            put("cid", JSONObject.NULL); put("nci", nci ?: JSONObject.NULL)
            put("pci", pci ?: JSONObject.NULL); put("earfcn", JSONObject.NULL); put("nrarfcn", nrarfcn ?: JSONObject.NULL)
            put("band", JSONObject.NULL)
            put("rsrp", rsrp?.let { clamp(it, -140.0, -50.0) } ?: JSONObject.NULL)
            put("rsrq", rsrq?.let { clamp(it, -25.0, -1.0) } ?: JSONObject.NULL)
            put("sinr", sinr?.let { clamp(it, -10.0, 30.0) } ?: JSONObject.NULL)
            put("rssi", JSONObject.NULL)
            put("timestamp", System.currentTimeMillis())
        }
    }

    // Fallback KPI extraction from SignalStrength when serving cell object is unavailable
    private fun guessKpisFromSignalStrength(ss: SignalStrength, rat: String): Triple<Double?, Double?, Double?> =
        try {
            if (rat == "NR" && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val nr = ss.getCellSignalStrengths(CellSignalStrengthNr::class.java).firstOrNull()
                val rsrp = nr?.ssRsrp?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                    ?: nr?.csiRsrp?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                val rsrq = nr?.ssRsrq?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                    ?: nr?.csiRsrq?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                val sinr = nr?.ssSinr?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                    ?: nr?.csiSinr?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                Triple(rsrp, rsrq, sinr)
            } else {
                val lte = ss.getCellSignalStrengths(CellSignalStrengthLte::class.java).firstOrNull()
                val rsrp = lte?.rsrp?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                val rsrq = lte?.rsrq?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                val sinr = lte?.rssnr?.takeIf { it != Int.MAX_VALUE }?.toDouble()
                Triple(rsrp, rsrq, sinr)
            }
        } catch (_: Throwable) { Triple(null, null, null) }

    // Pick first valid value (Int.MAX_VALUE means "unknown")
    private fun pickValid(primary: Int, secondary: Int): Int? =
        when {
            primary != Int.MAX_VALUE -> primary
            secondary != Int.MAX_VALUE -> secondary
            else -> null
        }

    // Emit JSON string to Flutter on the main thread
    private fun post(events: EventChannel.EventSink?, payload: JSONObject) {
        mainHandler.post { events?.success(payload.toString()) }
    }
    // Clamp numeric ranges to sensible KPI bounds
    private fun clamp(v: Double, lo: Double, hi: Double): Double = max(lo, min(hi, v))
}
