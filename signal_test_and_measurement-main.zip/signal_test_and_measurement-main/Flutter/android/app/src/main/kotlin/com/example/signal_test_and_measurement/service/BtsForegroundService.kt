package com.example.signal_test_and_measurement.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.example.signal_test_and_measurement.MainActivity
import com.example.signal_test_and_measurement.R
import com.example.signal_test_and_measurement.recorder.BtsRecorder
import android.content.pm.ServiceInfo
import android.Manifest
import android.content.pm.PackageManager


class BtsForegroundService : Service() {

    companion object {
        const val ACTION_START = "com.example.signal_test_and_measurement.action.START"
        const val ACTION_STOP  = "com.example.signal_test_and_measurement.action.STOP"

        private const val CHANNEL_ID   = "bts_recorder_channel"
        private const val CHANNEL_NAME = "BTS Recorder"
        private const val NOTIF_ID     = 42
    }

    private lateinit var recorder: BtsRecorder

    override fun onCreate() {
        super.onCreate()
        recorder = BtsRecorder(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            // Stop action
            ACTION_STOP -> {
                runCatching { recorder.stop() }
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                return START_NOT_STICKY
            }
            // Default = start
            else -> {
                if (!hasLocationPermission()) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                val notif = buildNotification()
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    startForeground(
                        NOTIF_ID,
                        notif,
                        ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
                    )
                } else {
                    @Suppress("DEPRECATION")
                    startForeground(NOTIF_ID, notif)
                }
                recorder.start()
                return START_STICKY
            }
        }
    }

    /** Check if app has at least one location permission */
    private fun hasLocationPermission(): Boolean {
        val fine = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    override fun onDestroy() {
        runCatching { recorder.stop() }
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /** Create notification channel (API 26+) */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val ch = NotificationChannel(
                CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Background measurement running"
                setShowBadge(false)
            }
            mgr.createNotificationChannel(ch)
        }
    }

    /** Build persistent notification with stop button */
    private fun buildNotification(): Notification {
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, BtsForegroundService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("BTS Recorder running")
            .setContentText("Background measurement active")
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(0, "Stop", stopIntent)
            .build()
    }
}
